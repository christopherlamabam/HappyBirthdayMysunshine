# Editing Your 22nd Birthday Keepsake

Yes — every word, photo, and gift detail can be edited. There are two ways to do it.

---

## Option 1 — Edit inside the webpage (no code required)

1. Open the page and click the wax seal to enter.
2. Click **“Edit Page”** in the top navigation (pencil icon), or **“Personalize Names, Photos & Details”** in the footer.
   - You can also open the editor directly with `?customize=1` added to the URL.
3. Choose a tab and edit:
   - **Names & Hero** — her name, nickname, your name, her birthdate, envelope note, hero eyebrow/headline/subtitle, and every section title and subtitle.
   - **Photos & Memories** — **upload photos directly from your phone or computer**, or paste an image URL. You can replace any single Polaroid with its own **Upload** button, or use the big upload panel to fill the sample Polaroids in order. Add extra ones with **+ Add Another Polaroid**.
   - **22 Reasons** — the title, tag, and note for each of the 22 cards.
   - **Love Letter** — headline, date stamp, greeting, letter paragraphs (separate paragraphs with a blank line), and sign-off.
   - **Birthday Voucher** — real gift title, description, timing, place/dress code, and bonus promise.
4. Click **Apply & Preview** to see it live.

### How photo uploading works
- Open **Photos & Memories**, then either **drag & drop** your photos onto the upload panel or click **Choose Photos From Device**.
- Each picture is automatically resized to a maximum of 1400 px and compressed to roughly 100–340 KB, then saved privately in your browser. You do not need to move files into any project folder.
- Uploading several photos fills Polaroids **#1 onward**, replacing the sample pictures. Use each card’s **Upload** button to swap just one picture.
- A storage meter shows how much browser space your photos use. Browsers allow about 5 MB, which is normally 15–25 compressed photos.
- When everything looks right, click **Download Gift Page**. This creates a standalone `.html` file with your words **and uploaded photos embedded** — perfect for opening on her phone, sharing by email, or keeping forever.

### Saving & sending it to her
- Edits save in your browser so you can keep tweaking.
- **Copy Shareable Gift Link** copies a link containing your text. Uploaded photos cannot fit inside a normal URL, so this link is best when your photos are hosted online (or use **Download Gift Page** to carry uploaded photos with the gift).
- **Export TS** downloads a ready-to-use data file if you prefer to keep the content in the project.

> Note: browser-saved edits apply to *your* browser. For a permanent public version, use the downloaded gift page, the shareable link, or edit the source data (Option 2).

### If a photo still won’t upload
| Problem | Fix |
| --- | --- |
| iPhone HEIC photo won’t load | On iPhone: **Settings → Camera → Formats → Most Compatible**, or choose a JPG from your library. |
| “Browser storage is full” | Remove a Polaroid, upload smaller JPGs, or click **Download Gift Page** so photos live in the downloaded file instead of browser storage. |
| Nothing happens when I click Upload | Make sure the editor is open in a regular browser tab (not a private/incognito window with storage restrictions), and allow file access when your browser asks. |
| Photo is rotated | Re-save it from your phone’s photo editor, or re-upload the JPG version. |
| Photo is blurry | Use a photo at least 1200 px wide. The editor keeps that quality while compressing the file size. |

> A webpage cannot silently write files into a project folder on the web — browsers block that for security. That is why the editor converts photos to embedded image data (and why **Download Gift Page** exists). If you want the photo permanently bundled with the source code, use the `public/photos/` method under Option 2.

---

## Option 2 — Edit the source data file (best for photos & permanent publishing)

All default content lives in:

```
src/data/giftData.ts   →  DEFAULT_GIFT_DATA
```

Edit these fields directly:

| Field | What it changes |
| --- | --- |
| `recipientName` | Her name throughout the page |
| `recipientNickname` | Handwritten dedication in the hero |
| `senderName` | Who the gift is from |
| `birthDate` | Powers the live years/days/seconds counter (`YYYY-MM-DD`) |
| `birthdayDisplayDate` | Envelope + footer date line |
| `envelopeNote` | Handwriting on the front of the sealed envelope |
| `heroEyebrow` / `heroHeadline` / `heroSubtitle` | Opening chapter text |
| `memories[]` | The 6 Polaroids (`imageUrl`, `dateLabel`, `location`, `caption`, `backStory`) |
| `memoriesHeading` / `memoriesSubheading` | Memories section titles |
| `reasons[]` | All 22 cards (`number`, `title`, `note`, `tag`) |
| `reasonsHeading` / `reasonsSubheading` | 22 Reasons section titles |
| `letterHeading` / `letterDate` / `letterGreeting` / `letterParagraphs` / `letterClosing` | The love letter |
| `wishStageHeadline` / `wishStageSubheading` | Candle / wish section text |
| `coupon.*` | The birthday gift voucher |

### Adding your own photos in the source code
1. Create a folder: `public/photos/`.
2. Drop your photos in, e.g. `public/photos/beach.jpg`.
3. In `giftData.ts`, set `imageUrl: "/photos/beach.jpg"`.
4. Run `npm run build` and publish the `dist/` output.

You can also paste direct image links (Cloudinary, Imgur, etc.). Use landscape or 4:3 photos for the best Polaroid framing.

> **Why you cannot “upload” from Option 2’s source file:** `giftData.ts` is a code file, not a file picker. To use your own pictures, either place them in `public/photos/` and reference the path, or use **Edit Page → Photos & Memories → Upload Photos** (which converts them automatically).

### Changing the design or animation
- `src/components/EnvelopeIntro.tsx` — wax-seal envelope opening
- `src/components/HeroChapter.tsx` — hero, monogram, botanical art, live counter
- `src/components/MemoriesGallery.tsx` — flip Polaroids + memory reel
- `src/components/ReasonsDeck.tsx` — 22-card deck
- `src/components/LoveLetterSection.tsx` — letter layout
- `src/components/CandleWishStage.tsx` — 22 candles, blow-out animation, confetti
- `src/components/BirthdayGiftPass.tsx` — gift voucher + wish time capsule
- `src/components/CustomizeStudioModal.tsx` — the editor
- `src/data/giftData.ts` — all default text, photos, and colors of content
- `src/index.css` — fonts, textures, 3D flip and candle-flame animations
- `src/utils/soundEngine.ts` — synthesized music-box melody and chimes

### Publishing
```bash
npm run build
```
Upload the generated `dist/` folder (or the single `dist/index.html`) to any static host — Netlify, Vercel, GitHub Pages, or send the file directly.

---

## Quick notes
- The **22** theme is intentional: 22 candles, 22 reasons, and a chapter-22 hero. If you change the age, update the headings and `reasons` count together.
- Music starts only after she taps the wax seal and only if “Gentle music box chime” is on. She can mute it any time from the top bar.
- Sound is generated in-browser (no audio files needed) and works after the first tap.
- The “Claimed” stamp and her Year 22 wish note are stored locally on her device.
