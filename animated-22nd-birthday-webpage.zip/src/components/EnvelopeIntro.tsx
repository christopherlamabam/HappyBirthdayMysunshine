import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Sparkles, Volume2, VolumeX } from "lucide-react";
import { soundEngine } from "../utils/soundEngine";

interface EnvelopeIntroProps {
  recipientName: string;
  senderName: string;
  envelopeNote: string;
  displayDate: string;
  onOpenComplete: (withMusic: boolean) => void;
}

export function EnvelopeIntro({
  recipientName,
  senderName,
  envelopeNote,
  displayDate,
  onOpenComplete,
}: EnvelopeIntroProps) {
  const [stage, setStage] = useState<"sealed" | "unfolding" | "sliding">("sealed");
  const [enableSound, setEnableSound] = useState(true);

  const handleBreakSeal = () => {
    if (stage !== "sealed") return;

    if (enableSound) {
      soundEngine.playSealChime();
    }

    setStage("unfolding");
    window.setTimeout(() => {
      setStage("sliding");
    }, 650);

    window.setTimeout(() => {
      onOpenComplete(enableSound);
    }, 1550);
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0, scale: 1.04, filter: "blur(6px)" }}
      transition={{ duration: 0.75, ease: [0.22, 1, 0.36, 1] }}
      className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-[#FAF6F0] px-4 py-8 paper-grain"
    >
      {/* Warm Radial Ambient Halo */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_50%_45%,rgba(232,200,155,0.28),transparent_65%)]"
      />

      {/* Top Subtle Postmark Eyebrow */}
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2, duration: 0.8 }}
        className="relative z-10 mb-8 text-center"
      >
        <p className="font-body text-[11px] font-medium uppercase tracking-[0.28em] text-[#8E3B46]/80">
          {displayDate} · Private Delivery
        </p>
      </motion.div>

      {/* Envelope Container */}
      <div className="relative z-10 w-full max-w-[460px] perspective-1200">
        {/* Letter Card Emerging Out of Envelope */}
        <AnimatePresence>
          {stage === "sliding" && (
            <motion.div
              initial={{ y: 20, opacity: 0, scale: 0.94 }}
              animate={{ y: -95, opacity: 1, scale: 1 }}
              transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
              className="pointer-events-none absolute inset-x-4 top-2 z-20 rounded-xl border border-[#E5D5C5] bg-[#FFFDF9] p-6 text-center shadow-2xl"
            >
              <p className="font-editorial text-xs uppercase tracking-[0.25em] text-[#C69C6D]">
                Happy 22nd Birthday
              </p>
              <h2 className="mt-2 font-editorial text-3xl italic text-[#261C1A]">
                For {recipientName}
              </h2>
              <div className="mx-auto mt-3 h-px w-16 bg-[#C69C6D]/50" />
            </motion.div>
          )}
        </AnimatePresence>

        {/* Main Envelope Body */}
        <motion.div
          initial={{ y: 24, opacity: 0, rotate: -1 }}
          animate={{
            y: stage === "sliding" ? 28 : 0,
            opacity: 1,
            rotate: stage === "sealed" ? -0.8 : 0,
          }}
          transition={{ duration: 0.85, ease: [0.22, 1, 0.36, 1] }}
          onClick={handleBreakSeal}
          role="button"
          tabIndex={0}
          onKeyDown={(e) => {
            if (e.key === "Enter" || e.key === " ") handleBreakSeal();
          }}
          aria-label={`Open birthday envelope for ${recipientName}`}
          className="group relative aspect-[4/2.75] w-full cursor-pointer select-none rounded-2xl border border-[#E2D2C2] bg-gradient-to-br from-[#FBF6EE] via-[#F6ECE0] to-[#EDE0D1] shadow-[0_30px_70px_-20px_rgba(38,28,26,0.22)] transition-shadow duration-500 hover:shadow-[0_36px_80px_-18px_rgba(142,59,70,0.24)]"
        >
          {/* Decorative Pressed Botanical SVG Sprig on Corner */}
          <svg
            aria-hidden="true"
            viewBox="0 0 120 120"
            className="pointer-events-none absolute bottom-3 left-3 h-20 w-20 text-[#8E3B46]/20"
            fill="none"
            stroke="currentColor"
            strokeWidth="1.2"
          >
            <path d="M18 102 C35 78, 52 58, 86 26" strokeLinecap="round" />
            <path d="M40 76 C28 68, 22 58, 25 46 C36 50, 42 62, 40 76Z" fill="currentColor" opacity="0.25" />
            <path d="M56 58 C68 62, 78 58, 84 48 C72 44, 62 48, 56 58Z" fill="currentColor" opacity="0.25" />
            <path d="M68 44 C56 36, 52 26, 56 16 C66 22, 72 32, 68 44Z" fill="currentColor" opacity="0.25" />
          </svg>

          {/* Subtle Inner Envelope Diagonal Creases */}
          <svg
            aria-hidden="true"
            viewBox="0 0 460 316"
            preserveAspectRatio="none"
            className="pointer-events-none absolute inset-0 h-full w-full rounded-2xl"
          >
            <path
              d="M0 316 L230 155 L460 316"
              fill="rgba(255,253,249,0.45)"
              stroke="#E2D2C2"
              strokeWidth="1.2"
            />
            <path
              d="M0 0 L195 158 M460 0 L265 158"
              stroke="#E2D2C2"
              strokeWidth="1"
              opacity="0.7"
            />
          </svg>

          {/* Postage Stamp Top Right */}
          <div className="pointer-events-none absolute right-5 top-4 flex flex-col items-center rounded border border-dashed border-[#C69C6D]/60 bg-[#FFFDF9]/80 px-2.5 py-1.5 shadow-sm">
            <span className="font-editorial text-sm font-semibold text-[#8E3B46]">22¢</span>
            <span className="font-body text-[8px] uppercase tracking-widest text-[#9A857E]">
              Love Mail
            </span>
          </div>

          {/* Handwritten Front Note */}
          <div className="pointer-events-none absolute inset-x-8 bottom-7 text-center">
            <p className="font-handwritten text-2xl leading-snug text-[#261C1A] sm:text-[27px]">
              {envelopeNote}
            </p>
            <p className="mt-1 font-body text-[11px] uppercase tracking-[0.22em] text-[#8E3B46]/70">
              From {senderName}
            </p>
          </div>

          {/* Top Folded Flap (3D Animated on Open) */}
          <motion.div
            animate={
              stage === "sealed"
                ? { rotateX: 0 }
                : { rotateX: -175, zIndex: 5 }
            }
            transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
            style={{ transformOrigin: "top center", transformStyle: "preserve-3d" }}
            className="pointer-events-none absolute inset-x-0 top-0 z-30 h-[56%]"
          >
            <svg
              viewBox="0 0 460 180"
              preserveAspectRatio="none"
              className="h-full w-full drop-shadow-[0_6px_12px_rgba(38,28,26,0.08)]"
            >
              <path
                d="M0 0 L460 0 L238 172 C233 176 227 176 222 172 Z"
                fill="#F7EFE5"
                stroke="#DFCEBD"
                strokeWidth="1.2"
              />
            </svg>
          </motion.div>

          {/* 3D Crimson Wax Seal Stamped "22" */}
          <motion.div
            animate={
              stage === "sealed"
                ? { scale: 1, opacity: 1 }
                : { scale: 1.25, opacity: 0, rotate: 18 }
            }
            whileHover={stage === "sealed" ? { scale: 1.08 } : undefined}
            whileTap={stage === "sealed" ? { scale: 0.94 } : undefined}
            transition={{ duration: 0.45, ease: "easeOut" }}
            className="absolute left-1/2 top-[48%] z-40 -translate-x-1/2 -translate-y-1/2"
          >
            {/* Outer organic wax ring */}
            <div className="relative flex h-20 w-20 items-center justify-center rounded-full bg-gradient-to-br from-[#A64452] via-[#8E3B46] to-[#63222B] shadow-[0_10px_22px_rgba(99,34,43,0.42),inset_0_2px_4px_rgba(255,215,215,0.35)] ring-4 ring-[#8E3B46]/20">
              {/* Embossed Inner Circle */}
              <div className="flex h-14 w-14 flex-col items-center justify-center rounded-full border border-[#F5D6B8]/45 bg-[#7B2F39]/70 shadow-inner">
                <span className="font-editorial text-2xl font-semibold italic leading-none text-[#FAE8D4]">
                  22
                </span>
                <span className="mt-0.5 text-[7px] uppercase tracking-[0.24em] text-[#FAE8D4]/80">
                  Years
                </span>
              </div>

              {/* Subtle Hover Pulse Halo */}
              <span className="pointer-events-none absolute -inset-2 animate-ping rounded-full border border-[#8E3B46]/25 [animation-duration:2.6s]" />
            </div>
          </motion.div>
        </motion.div>
      </div>

      {/* Bottom Prompt & Sound Preference */}
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.45, duration: 0.7 }}
        className="relative z-10 mt-10 flex flex-col items-center gap-4 text-center"
      >
        <button
          onClick={handleBreakSeal}
          className="inline-flex items-center gap-2 rounded-full border border-[#8E3B46]/25 bg-[#FFFDF9] px-5 py-2.5 font-body text-xs font-medium tracking-[0.14em] uppercase text-[#8E3B46] shadow-sm transition-all hover:border-[#8E3B46]/50 hover:bg-[#8E3B46] hover:text-white"
        >
          <Sparkles className="h-3.5 w-3.5" />
          Tap the Wax Seal to Open
        </button>

        <button
          type="button"
          onClick={() => setEnableSound((prev) => !prev)}
          className="inline-flex items-center gap-1.5 text-xs text-[#6B5853] transition-colors hover:text-[#261C1A]"
        >
          {enableSound ? (
            <>
              <Volume2 className="h-3.5 w-3.5 text-[#C69C6D]" />
              <span>Gentle music box chime: On</span>
            </>
          ) : (
            <>
              <VolumeX className="h-3.5 w-3.5 text-[#9A857E]" />
              <span>Gentle music box chime: Off</span>
            </>
          )}
        </button>
      </motion.div>
    </motion.div>
  );
}
