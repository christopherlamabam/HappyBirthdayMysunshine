import { useState } from "react";
import { motion } from "framer-motion";
import { Feather } from "lucide-react";

interface LoveLetterSectionProps {
  heading: string;
  letterDate: string;
  greeting: string;
  paragraphs: string[];
  closing: string;
  senderName: string;
}

export function LoveLetterSection({
  heading,
  letterDate,
  greeting,
  paragraphs,
  closing,
  senderName,
}: LoveLetterSectionProps) {
  const [replaySeed, setReplaySeed] = useState(0);

  return (
    <section
      id="letter"
      className="relative mx-auto max-w-4xl px-4 py-24 sm:px-8 sm:py-32"
    >
      {/* Section Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, amount: 0.3 }}
        transition={{ duration: 0.7 }}
        className="mb-10 text-center"
      >
        <span className="font-body text-xs font-medium uppercase tracking-[0.26em] text-[#8E3B46]">
          Chapter III · In Writing
        </span>
        <h2 className="mt-3 font-editorial text-4xl font-medium text-[#261C1A] sm:text-5xl">
          {heading}
        </h2>
      </motion.div>

      {/* Stationary Card */}
      <motion.article
        key={replaySeed}
        initial={{ opacity: 0, y: 32 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, amount: 0.15 }}
        transition={{ duration: 0.85, ease: [0.22, 1, 0.36, 1] }}
        className="relative overflow-hidden rounded-2xl border border-[#DFCBB8] bg-[#FFFDF9] p-7 shadow-[0_30px_70px_-28px_rgba(38,28,26,0.18)] sm:p-14"
      >
        {/* Inner Stationary Hairline Frame */}
        <div
          aria-hidden="true"
          className="pointer-events-none absolute inset-3 rounded-xl border border-[#C69C6D]/25 sm:inset-5"
        />

        {/* Pressed Botanical Corner Illustration */}
        <svg
          aria-hidden="true"
          viewBox="0 0 120 120"
          className="pointer-events-none absolute right-6 top-6 h-20 w-20 text-[#8E3B46]/15 sm:right-10 sm:top-10"
          fill="none"
          stroke="currentColor"
          strokeWidth="1.2"
        >
          <motion.path
            d="M25 95 C45 75, 70 50, 96 22"
            initial={{ pathLength: 0 }}
            whileInView={{ pathLength: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 1.4, ease: "easeInOut" }}
          />
          <circle cx="96" cy="22" r="4" fill="currentColor" opacity="0.3" />
          <path d="M55 66 C42 58, 40 46, 48 38 C58 44, 62 56, 55 66Z" fill="currentColor" opacity="0.2" />
          <path d="M72 48 C84 52, 94 46, 98 36 C86 32, 76 38, 72 48Z" fill="currentColor" opacity="0.2" />
        </svg>

        <div className="relative z-10 mx-auto max-w-2xl">
          {/* Date Stamp & Crest */}
          <div className="flex flex-col items-start justify-between gap-2 border-b border-[#EFE3D7] pb-6 sm:flex-row sm:items-center">
            <span className="font-body text-[11px] font-medium uppercase tracking-[0.22em] text-[#9A857E]">
              {letterDate}
            </span>
            <button
              type="button"
              onClick={() => setReplaySeed((s) => s + 1)}
              className="inline-flex items-center gap-1.5 font-body text-[11px] font-medium text-[#C69C6D] transition-colors hover:text-[#8E3B46]"
            >
              <Feather className="h-3.5 w-3.5" />
              Replay ink animation
            </button>
          </div>

          {/* Salutation */}
          <motion.p
            initial={{ opacity: 0, y: 12 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7, delay: 0.1 }}
            className="mt-8 font-editorial text-3xl italic text-[#8E3B46] sm:text-4xl"
          >
            {greeting}
          </motion.p>

          {/* Body Paragraphs */}
          <div className="mt-7 space-y-6">
            {paragraphs.map((para, idx) => (
              <motion.p
                key={idx}
                initial={{ opacity: 0, y: 14 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.4 }}
                transition={{
                  duration: 0.75,
                  delay: 0.15 + idx * 0.14,
                  ease: [0.22, 1, 0.36, 1],
                }}
                className="font-body text-[16px] leading-[1.85] text-[#3B2D2A] sm:text-[17px]"
              >
                {para}
              </motion.p>
            ))}
          </div>

          {/* Closing & Calligraphic Signature */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.35 }}
            className="mt-10 border-t border-[#EFE3D7] pt-8"
          >
            <p className="font-editorial text-xl italic text-[#6B5853]">
              {closing}
            </p>

            <div className="mt-3 flex flex-col items-start gap-2">
              <span className="font-handwritten text-5xl text-[#8E3B46]">
                {senderName}
              </span>

              {/* Self-Drawing Signature Underline Flourish */}
              <svg
                viewBox="0 0 220 24"
                className="h-5 w-44 text-[#C69C6D]"
                fill="none"
              >
                <motion.path
                  d="M4 14 C55 4, 125 22, 212 8"
                  stroke="currentColor"
                  strokeWidth="1.8"
                  strokeLinecap="round"
                  initial={{ pathLength: 0 }}
                  whileInView={{ pathLength: 1 }}
                  viewport={{ once: true }}
                  transition={{ duration: 1.3, delay: 0.5, ease: "easeOut" }}
                />
              </svg>
            </div>
          </motion.div>
        </div>
      </motion.article>
    </section>
  );
}
