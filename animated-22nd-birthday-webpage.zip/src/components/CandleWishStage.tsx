import { useEffect, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import confetti from "canvas-confetti";
import { Flame, RotateCcw, Sparkles, Wind } from "lucide-react";
import { soundEngine } from "../utils/soundEngine";

interface CandleWishStageProps {
  recipientName: string;
  headline: string;
  subheading: string;
  isMusicPlaying: boolean;
  onWishMade?: () => void;
}

interface CandleSpec {
  id: number;
  x: number;
  y: number;
  height: number;
  delay: number;
}

// 22 candles arranged artfully across two cake tiers (10 upper tier, 12 lower rim)
const CANDLES: CandleSpec[] = [
  // Top Tier: 10 candles
  ...Array.from({ length: 10 }, (_, i) => ({
    id: i + 1,
    x: 170 + i * 24.4,
    y: 122,
    height: i % 2 === 0 ? 44 : 39,
    delay: (i * 0.14) % 1.2,
  })),
  // Lower Tier Rim: 12 candles (6 left shoulder, 6 right shoulder)
  ...Array.from({ length: 6 }, (_, i) => ({
    id: 11 + i,
    x: 78 + i * 16,
    y: 186,
    height: i % 2 === 0 ? 38 : 34,
    delay: ((i + 3) * 0.17) % 1.2,
  })),
  ...Array.from({ length: 6 }, (_, i) => ({
    id: 17 + i,
    x: 398 + i * 16,
    y: 186,
    height: i % 2 === 0 ? 38 : 34,
    delay: ((i + 5) * 0.15) % 1.2,
  })),
];

export function CandleWishStage({
  recipientName,
  headline,
  subheading,
  isMusicPlaying,
  onWishMade,
}: CandleWishStageProps) {
  const [litCandles, setLitCandles] = useState<boolean[]>(() =>
    Array(22).fill(true)
  );
  const [isBlowingSweep, setIsBlowingSweep] = useState(false);
  const celebratedRef = useRef(false);

  const litCount = litCandles.filter(Boolean).length;
  const allOut = litCount === 0;

  useEffect(() => {
    if (allOut && !celebratedRef.current) {
      celebratedRef.current = true;
      onWishMade?.();

      if (isMusicPlaying) {
        soundEngine.playCelebrationArpeggio();
      }

      confetti({
        particleCount: 90,
        spread: 85,
        origin: { y: 0.62 },
        colors: ["#E8C89B", "#F5B971", "#8E3B46", "#FFFDF9", "#C69C6D"],
      });

      window.setTimeout(() => {
        confetti({
          particleCount: 45,
          angle: 60,
          spread: 55,
          origin: { x: 0.15, y: 0.65 },
          colors: ["#E8C89B", "#F5B971", "#FAF6F0"],
        });
        confetti({
          particleCount: 45,
          angle: 120,
          spread: 55,
          origin: { x: 0.85, y: 0.65 },
          colors: ["#E8C89B", "#F5B971", "#FAF6F0"],
        });
      }, 280);
    }
  }, [allOut, isMusicPlaying, onWishMade]);

  const extinguishSingle = (index: number) => {
    setLitCandles((prev) => {
      if (!prev[index]) return prev;
      const next = [...prev];
      next[index] = false;
      return next;
    });
  };

  const handleBlowAll = () => {
    if (allOut || isBlowingSweep) return;
    setIsBlowingSweep(true);

    // Cascade extinguishing left-to-right across x coordinate
    const sorted = [...CANDLES].sort((a, b) => a.x - b.x);
    sorted.forEach((candle, orderIdx) => {
      window.setTimeout(() => {
        extinguishSingle(candle.id - 1);
      }, orderIdx * 48);
    });

    window.setTimeout(() => {
      setIsBlowingSweep(false);
    }, sorted.length * 48 + 300);
  };

  const handleRelight = () => {
    celebratedRef.current = false;
    setLitCandles(Array(22).fill(true));
  };

  // Ambient glow intensity scales with how many candles remain lit
  const glowRatio = litCount / 22;

  return (
    <section
      id="wish"
      className="relative overflow-hidden bg-[#1C1417] py-24 text-[#FAF6F0] sm:py-32"
    >
      {/* Twinkling Starfield Backdrop */}
      <div aria-hidden="true" className="pointer-events-none absolute inset-0">
        {Array.from({ length: 28 }).map((_, idx) => (
          <motion.span
            key={idx}
            animate={{ opacity: [0.15, 0.7, 0.15], scale: [0.8, 1.2, 0.8] }}
            transition={{
              duration: 2.5 + (idx % 4),
              repeat: Infinity,
              delay: (idx * 0.27) % 3,
            }}
            className="absolute h-1 w-1 rounded-full bg-[#E8C89B]"
            style={{
              left: `${(idx * 37) % 100}%`,
              top: `${(idx * 23) % 90}%`,
            }}
          />
        ))}
      </div>

      {/* Warm Candlelight Radial Halo */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute left-1/2 top-1/2 h-[540px] w-[540px] -translate-x-1/2 -translate-y-1/2 rounded-full transition-opacity duration-700"
        style={{
          opacity: 0.12 + glowRatio * 0.68,
          background:
            "radial-gradient(circle, rgba(245,185,113,0.34) 0%, rgba(198,156,109,0.14) 42%, transparent 72%)",
        }}
      />

      <div className="relative z-10 mx-auto max-w-4xl px-4 text-center sm:px-8">
        {/* Eyebrow & Heading */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.75 }}
        >
          <span className="font-body text-xs font-medium uppercase tracking-[0.26em] text-[#E8C89B]">
            Chapter IV · Make a Wish
          </span>
          <h2 className="mt-3 font-editorial text-4xl font-medium text-[#FAF6F0] sm:text-5xl">
            {headline}
          </h2>
          <p className="mx-auto mt-4 max-w-xl font-body text-sm leading-relaxed text-[#D8C7BA] sm:text-base">
            {subheading}
          </p>
        </motion.div>

        {/* Interactive 22-Candle Birthday Cake Stage */}
        <div className="relative mx-auto mt-10 max-w-[560px] select-none">
          {/* Sweeping Wind Breeze Shimmer when Blowing All */}
          <AnimatePresence>
            {isBlowingSweep && (
              <motion.div
                initial={{ x: "-30%", opacity: 0 }}
                animate={{ x: "110%", opacity: [0, 0.9, 0] }}
                exit={{ opacity: 0 }}
                transition={{ duration: 1.15, ease: "easeInOut" }}
                className="pointer-events-none absolute inset-y-8 left-0 z-30 w-44 bg-gradient-to-r from-transparent via-[#E8C89B]/25 to-transparent blur-md"
              />
            )}
          </AnimatePresence>

          <svg
            viewBox="0 0 560 360"
            className="mx-auto h-auto w-full drop-shadow-[0_24px_45px_rgba(0,0,0,0.45)]"
            role="img"
            aria-label={`Birthday cake with ${litCount} of 22 candles lit`}
          >
            <defs>
              <radialGradient id="flameGlow" cx="50%" cy="50%" r="50%">
                <stop offset="0%" stopColor="#FFE8A3" stopOpacity="0.85" />
                <stop offset="45%" stopColor="#F5B971" stopOpacity="0.35" />
                <stop offset="100%" stopColor="#F5B971" stopOpacity="0" />
              </radialGradient>
              <linearGradient id="cakeFrostingTop" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#FFF8F0" />
                <stop offset="100%" stopColor="#F0E0D0" />
              </linearGradient>
              <linearGradient id="cakeFrostingBase" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#F7EBDD" />
                <stop offset="100%" stopColor="#E4CDB8" />
              </linearGradient>
              <linearGradient id="cakeStand" x1="0" y1="0" x2="1" y2="0">
                <stop offset="0%" stopColor="#A67D52" />
                <stop offset="50%" stopColor="#E8C89B" />
                <stop offset="100%" stopColor="#A67D52" />
              </linearGradient>
            </defs>

            {/* Cake Pedestal Stand */}
            <path
              d="M250 296 L310 296 L328 332 L232 332 Z"
              fill="url(#cakeStand)"
              opacity="0.92"
            />
            <ellipse cx="280" cy="333" rx="85" ry="10" fill="url(#cakeStand)" />
            <ellipse cx="280" cy="296" rx="236" ry="16" fill="#E8C89B" />
            <ellipse cx="280" cy="293" rx="232" ry="13" fill="#FFFDF9" opacity="0.7" />

            {/* Lower Cake Tier */}
            <rect
              x="64"
              y="186"
              width="432"
              height="106"
              rx="18"
              fill="url(#cakeFrostingBase)"
            />
            {/* Delicate Berry / Wine Scallop Drip */}
            <path
              d="M64 198 Q94 222 124 202 Q154 228 184 202 Q214 226 244 202 Q280 230 316 202 Q346 226 376 202 Q406 228 436 202 Q466 222 496 198 L496 186 L64 186 Z"
              fill="#8E3B46"
              opacity="0.22"
            />
            <ellipse cx="280" cy="186" rx="216" ry="12" fill="#FFFDF9" />

            {/* Upper Cake Tier */}
            <rect
              x="154"
              y="122"
              width="252"
              height="66"
              rx="14"
              fill="url(#cakeFrostingTop)"
            />
            <path
              d="M154 134 Q182 152 210 136 Q240 156 270 136 Q300 156 330 136 Q360 152 406 134 L406 122 L154 122 Z"
              fill="#C69C6D"
              opacity="0.25"
            />
            <ellipse cx="280" cy="122" rx="126" ry="9" fill="#FFFDF9" />

            {/* Cake Monogram Badge */}
            <circle cx="280" cy="242" r="24" fill="#FAF6F0" stroke="#C69C6D" strokeWidth="1.2" />
            <text
              x="280"
              y="249"
              textAnchor="middle"
              fill="#8E3B46"
              fontSize="20"
              fontStyle="italic"
              fontFamily="Cormorant Garamond, Georgia, serif"
              fontWeight="600"
            >
              22
            </text>

            {/* 22 Interactive Taper Candles */}
            {CANDLES.map((candle, index) => {
              const isLit = litCandles[index];
              const topY = candle.y - candle.height;

              return (
                <g
                  key={candle.id}
                  onClick={() => extinguishSingle(index)}
                  className="cursor-pointer"
                >
                  {/* Invisible Larger Hitbox for Easy Tapping */}
                  <rect
                    x={candle.x - 10}
                    y={topY - 26}
                    width="20"
                    height={candle.height + 28}
                    fill="transparent"
                  />

                  {/* Candle Wax Body */}
                  <rect
                    x={candle.x - 3.2}
                    y={topY}
                    width="6.4"
                    height={candle.height}
                    rx="2.5"
                    fill={index % 2 === 0 ? "#F4DEC2" : "#E8C89B"}
                    stroke="#C69C6D"
                    strokeWidth="0.6"
                  />
                  {/* Subtle Gold Stripe */}
                  <line
                    x1={candle.x - 3}
                    y1={topY + 12}
                    x2={candle.x + 3}
                    y2={topY + 15}
                    stroke="#8E3B46"
                    strokeWidth="1"
                    opacity="0.35"
                  />

                  {/* Wick */}
                  <line
                    x1={candle.x}
                    y1={topY}
                    x2={candle.x}
                    y2={topY - 5}
                    stroke="#3E2A28"
                    strokeWidth="1.2"
                  />

                  {/* Flickering Flame or Rising Smoke Wisp */}
                  {isLit ? (
                    <g>
                      <circle
                        cx={candle.x}
                        cy={topY - 12}
                        r="18"
                        fill="url(#flameGlow)"
                      />
                      <g
                        className="animate-flame"
                        style={{
                          transformOrigin: `${candle.x}px ${topY - 4}px`,
                          animationDelay: `${candle.delay}s`,
                        }}
                      >
                        <path
                          d={`M ${candle.x} ${topY - 22} C ${candle.x + 5.5} ${
                            topY - 14
                          }, ${candle.x + 4.5} ${topY - 5}, ${candle.x} ${
                            topY - 4
                          } C ${candle.x - 4.5} ${topY - 5}, ${
                            candle.x - 5.5
                          } ${topY - 14}, ${candle.x} ${topY - 22} Z`}
                          fill="#F5B971"
                        />
                        <path
                          d={`M ${candle.x} ${topY - 17} C ${candle.x + 2.6} ${
                            topY - 11
                          }, ${candle.x + 2} ${topY - 6}, ${candle.x} ${
                            topY - 5.5
                          } C ${candle.x - 2} ${topY - 6}, ${
                            candle.x - 2.6
                          } ${topY - 11}, ${candle.x} ${topY - 17} Z`}
                          fill="#FFF6D6"
                        />
                      </g>
                    </g>
                  ) : (
                    <motion.path
                      initial={{ opacity: 0.75, y: 0 }}
                      animate={{ opacity: 0, y: -22 }}
                      transition={{ duration: 1.6, ease: "easeOut" }}
                      d={`M ${candle.x} ${topY - 6} Q ${candle.x - 4} ${
                        topY - 15
                      } ${candle.x + 2} ${topY - 24} T ${candle.x - 2} ${
                        topY - 38
                      }`}
                      fill="none"
                      stroke="#D8C7BA"
                      strokeWidth="1.3"
                      strokeLinecap="round"
                    />
                  )}
                </g>
              );
            })}
          </svg>
        </div>

        {/* Status & Controls */}
        <div className="mt-6 flex flex-col items-center gap-4">
          <AnimatePresence mode="wait">
            {!allOut ? (
              <motion.div
                key="lit"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="flex flex-col items-center gap-4"
              >
                <p className="inline-flex items-center gap-2 font-body text-xs uppercase tracking-[0.2em] text-[#E8C89B]/85">
                  <Flame className="h-3.5 w-3.5 text-[#F5B971]" />
                  {litCount} of 22 candles glowing
                </p>

                <button
                  type="button"
                  onClick={handleBlowAll}
                  disabled={isBlowingSweep}
                  className="inline-flex items-center gap-2.5 rounded-full bg-gradient-to-r from-[#E8C89B] to-[#C69C6D] px-7 py-3.5 font-body text-xs font-semibold uppercase tracking-[0.16em] text-[#1C1417] shadow-[0_12px_30px_rgba(232,200,155,0.3)] transition-transform hover:scale-[1.03] active:scale-[0.98] disabled:opacity-70"
                >
                  <Wind className="h-4 w-4" />
                  Make a Wish & Blow Out All 22
                </button>
              </motion.div>
            ) : (
              <motion.div
                key="wished"
                initial={{ opacity: 0, scale: 0.94, y: 12 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                transition={{ duration: 0.65, ease: [0.22, 1, 0.36, 1] }}
                className="max-w-lg rounded-2xl border border-[#E8C89B]/35 bg-[#2A1E22]/90 px-6 py-6 shadow-xl backdrop-blur-sm"
              >
                <div className="inline-flex items-center gap-1.5 text-xs font-medium uppercase tracking-[0.2em] text-[#F5B971]">
                  <Sparkles className="h-4 w-4" />
                  Happy 22nd Birthday, {recipientName}
                </div>
                <p className="mt-2 font-editorial text-2xl italic text-[#FAF6F0] sm:text-3xl">
                  “Your 22nd wish is sealed among the stars.”
                </p>
                <p className="mt-2 font-body text-xs text-[#D8C7BA]">
                  Scroll down to open your keepsake birthday voucher and save your wish for next year.
                </p>

                <div className="mt-5 flex flex-wrap items-center justify-center gap-3">
                  <a
                    href="#gift"
                    className="inline-flex items-center gap-2 rounded-full bg-[#8E3B46] px-5 py-2 font-body text-xs font-medium uppercase tracking-[0.14em] text-white transition-colors hover:bg-[#A64452]"
                  >
                    Unwrap Your Gift Pass ↓
                  </a>
                  <button
                    type="button"
                    onClick={handleRelight}
                    className="inline-flex items-center gap-1.5 rounded-full border border-[#E8C89B]/30 px-4 py-2 font-body text-xs text-[#E8C89B] transition-colors hover:bg-[#E8C89B]/10"
                  >
                    <RotateCcw className="h-3.5 w-3.5" />
                    Re-light Candles
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </section>
  );
}
