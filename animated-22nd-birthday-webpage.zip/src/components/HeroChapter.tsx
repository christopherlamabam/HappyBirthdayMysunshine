import { useEffect, useRef, useState } from "react";
import { motion, useScroll, useTransform } from "framer-motion";
import { ArrowDown, Sparkles } from "lucide-react";
import type { MemoryItem } from "../data/giftData";

interface HeroChapterProps {
  recipientName: string;
  recipientNickname: string;
  senderName: string;
  birthDate: string;
  eyebrow: string;
  headline: string;
  subtitle: string;
  previewMemories: MemoryItem[];
}

function computeLifeMetrics(birthDateStr: string) {
  const parsed = new Date(`${birthDateStr}T00:00:00`);
  const validDate = Number.isNaN(parsed.getTime())
    ? new Date("2004-05-14T00:00:00")
    : parsed;
  const now = new Date();
  const diffMs = Math.max(0, now.getTime() - validDate.getTime());
  const totalSeconds = Math.floor(diffMs / 1000);
  const totalHours = Math.floor(totalSeconds / 3600);
  const totalDays = Math.floor(totalHours / 24);
  return {
    years: 22,
    months: 264,
    days: totalDays > 0 ? totalDays : 8036,
    hours: totalHours > 0 ? totalHours : 192864,
    seconds: totalSeconds > 0 ? totalSeconds : 694310400,
  };
}

export function HeroChapter({
  recipientName,
  recipientNickname,
  senderName,
  birthDate,
  eyebrow,
  headline,
  subtitle,
  previewMemories,
}: HeroChapterProps) {
  const sectionRef = useRef<HTMLElement | null>(null);
  const [metrics, setMetrics] = useState(() => computeLifeMetrics(birthDate));

  useEffect(() => {
    setMetrics(computeLifeMetrics(birthDate));
    const interval = window.setInterval(() => {
      setMetrics(computeLifeMetrics(birthDate));
    }, 1000);
    return () => window.clearInterval(interval);
  }, [birthDate]);

  const { scrollYProgress } = useScroll({
    target: sectionRef,
    offset: ["start start", "end start"],
  });

  const leftFloatY = useTransform(scrollYProgress, [0, 1], [0, -90]);
  const rightFloatY = useTransform(scrollYProgress, [0, 1], [0, -135]);
  const badgeScale = useTransform(scrollYProgress, [0, 0.7], [1, 0.92]);

  const leftPhoto = previewMemories[0];
  const rightPhoto = previewMemories[2] || previewMemories[1];

  return (
    <section
      id="top"
      ref={sectionRef}
      className="relative flex min-h-screen flex-col items-center justify-center overflow-hidden px-4 pb-16 pt-28 sm:px-8"
    >
      {/* Soft Editorial Glow Backdrops */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute left-1/2 top-1/3 h-[540px] w-[540px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-[radial-gradient(circle,rgba(232,200,155,0.28)_0%,rgba(200,125,117,0.12)_45%,transparent_72%)] blur-2xl"
      />

      {/* Parallax Floating Memory Accent Left (Desktop) */}
      {leftPhoto && (
        <motion.div
          style={{ y: leftFloatY }}
          initial={{ opacity: 0, x: -40, rotate: -7 }}
          animate={{ opacity: 1, x: 0, rotate: -6 }}
          transition={{ duration: 1.1, delay: 0.45, ease: [0.22, 1, 0.36, 1] }}
          className="pointer-events-none absolute left-6 top-36 hidden w-44 rounded-lg border border-[#E6D7C8] bg-[#FFFDF9] p-2 pb-5 shadow-xl xl:left-14 xl:block 2xl:w-52"
        >
          <div className="aspect-[4/3] overflow-hidden rounded-sm bg-[#EFE2D7]">
            {leftPhoto.imageUrl ? (
              <img
                src={leftPhoto.imageUrl}
                alt={leftPhoto.caption}
                className="h-full w-full object-cover"
              />
            ) : (
              <div className="flex h-full w-full items-center justify-center bg-[radial-gradient(circle_at_50%_40%,#FBF2E7,#E8D3C2)]">
                <Sparkles className="h-6 w-6 text-[#8E3B46]/40" />
              </div>
            )}
          </div>
          <p className="mt-2 truncate px-1 text-center font-handwritten text-sm text-[#6B5853]">
            {leftPhoto.location}
          </p>
        </motion.div>
      )}

      {/* Parallax Floating Memory Accent Right (Desktop) */}
      {rightPhoto && (
        <motion.div
          style={{ y: rightFloatY }}
          initial={{ opacity: 0, x: 40, rotate: 6 }}
          animate={{ opacity: 1, x: 0, rotate: 5 }}
          transition={{ duration: 1.1, delay: 0.6, ease: [0.22, 1, 0.36, 1] }}
          className="pointer-events-none absolute bottom-28 right-6 hidden w-44 rounded-lg border border-[#E6D7C8] bg-[#FFFDF9] p-2 pb-5 shadow-xl xl:right-14 xl:block 2xl:w-52"
        >
          <div className="aspect-[4/3] overflow-hidden rounded-sm bg-[#EFE2D7]">
            {rightPhoto.imageUrl ? (
              <img
                src={rightPhoto.imageUrl}
                alt={rightPhoto.caption}
                className="h-full w-full object-cover"
              />
            ) : (
              <div className="flex h-full w-full items-center justify-center bg-[radial-gradient(circle_at_50%_40%,#FBF2E7,#E8D3C2)]">
                <Sparkles className="h-6 w-6 text-[#8E3B46]/40" />
              </div>
            )}
          </div>
          <p className="mt-2 truncate px-1 text-center font-handwritten text-sm text-[#6B5853]">
            {rightPhoto.location}
          </p>
        </motion.div>
      )}

      {/* Central Composition */}
      <div className="relative z-10 mx-auto max-w-3xl text-center">
        {/* Eyebrow Pill */}
        <motion.div
          initial={{ opacity: 0, y: 14 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.1 }}
          className="inline-flex items-center gap-2 rounded-full border border-[#C69C6D]/45 bg-[#FFFDF9]/90 px-4 py-1.5 shadow-xs"
        >
          <Sparkles className="h-3.5 w-3.5 text-[#C69C6D]" />
          <span className="font-body text-[11px] font-medium uppercase tracking-[0.22em] text-[#8E3B46]">
            {eyebrow}
          </span>
        </motion.div>

        {/* Sculptural "22" Emblem with Self-Drawing Botanical Laurel */}
        <motion.div
          style={{ scale: badgeScale }}
          className="relative mx-auto my-7 flex h-48 w-48 items-center justify-center sm:h-56 sm:w-56"
        >
          {/* Rotating Dotted Champagne Gold Ring */}
          <motion.svg
            animate={{ rotate: 360 }}
            transition={{ duration: 48, repeat: Infinity, ease: "linear" }}
            viewBox="0 0 220 220"
            className="absolute inset-0 h-full w-full"
          >
            <circle
              cx="110"
              cy="110"
              r="102"
              fill="none"
              stroke="#C69C6D"
              strokeWidth="1"
              strokeDasharray="3 7"
              opacity="0.55"
            />
            <circle
              cx="110"
              cy="110"
              r="90"
              fill="none"
              stroke="#8E3B46"
              strokeWidth="0.6"
              opacity="0.25"
            />
          </motion.svg>

          {/* Self-Drawing Botanical Wreath Left & Right */}
          <svg
            aria-hidden="true"
            viewBox="0 0 220 220"
            className="absolute inset-0 h-full w-full"
            fill="none"
          >
            <motion.path
              d="M42 152 C24 120, 26 78, 56 48"
              stroke="#8E3B46"
              strokeWidth="1.3"
              strokeLinecap="round"
              initial={{ pathLength: 0, opacity: 0 }}
              animate={{ pathLength: 1, opacity: 0.65 }}
              transition={{ duration: 1.5, delay: 0.3, ease: "easeInOut" }}
            />
            <motion.path
              d="M178 152 C196 120, 194 78, 164 48"
              stroke="#8E3B46"
              strokeWidth="1.3"
              strokeLinecap="round"
              initial={{ pathLength: 0, opacity: 0 }}
              animate={{ pathLength: 1, opacity: 0.65 }}
              transition={{ duration: 1.5, delay: 0.3, ease: "easeInOut" }}
            />
          </svg>

          {/* Center Cream Medallion + Giant 22 */}
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.85, delay: 0.2, ease: [0.22, 1, 0.36, 1] }}
            className="relative flex h-36 w-36 flex-col items-center justify-center rounded-full border border-[#E2D2C2] bg-[#FFFDF9]/95 shadow-[0_20px_50px_-15px_rgba(142,59,70,0.22)] sm:h-40 sm:w-40"
          >
            <span className="font-body text-[10px] font-medium uppercase tracking-[0.26em] text-[#9A857E]">
              Chapter
            </span>
            <span className="font-editorial text-7xl font-semibold italic leading-none text-[#8E3B46] sm:text-[82px]">
              22
            </span>
            <span className="mt-1 font-handwritten text-lg text-[#C69C6D]">
              {recipientName}
            </span>
          </motion.div>
        </motion.div>

        {/* Headline */}
        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.85, delay: 0.35, ease: [0.22, 1, 0.36, 1] }}
          className="font-editorial text-4xl font-medium leading-[1.08] tracking-tight text-[#261C1A] sm:text-6xl"
        >
          {headline}
        </motion.h1>

        {/* Subcopy */}
        <motion.p
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.85, delay: 0.5 }}
          className="mx-auto mt-5 max-w-xl font-body text-base leading-relaxed text-[#6B5853] sm:text-[17px]"
        >
          {subtitle}
        </motion.p>

        {/* Handwritten Dedication Tag */}
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8, delay: 0.65 }}
          className="mt-4 font-handwritten text-2xl text-[#8E3B46]"
        >
          Happy 22nd Birthday, {recipientNickname} — love, {senderName}
        </motion.p>

        {/* Live 22-Year Milestone Counter Ribbon */}
        <motion.div
          initial={{ opacity: 0, y: 18 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.85, delay: 0.72 }}
          className="mx-auto mt-9 grid max-w-2xl grid-cols-2 gap-3 rounded-2xl border border-[#E5D5C5] bg-[#FFFDF9]/85 p-4 shadow-sm backdrop-blur-xs sm:grid-cols-4 sm:gap-4"
        >
          <div className="rounded-xl bg-[#FAF6F0]/80 px-3 py-2.5">
            <p className="font-editorial text-2xl font-semibold text-[#8E3B46] sm:text-3xl">
              {metrics.years}
            </p>
            <p className="font-body text-[10px] font-medium uppercase tracking-[0.18em] text-[#9A857E]">
              Luminous Years
            </p>
          </div>
          <div className="rounded-xl bg-[#FAF6F0]/80 px-3 py-2.5">
            <p className="font-editorial text-2xl font-semibold text-[#261C1A] sm:text-3xl">
              {metrics.months}
            </p>
            <p className="font-body text-[10px] font-medium uppercase tracking-[0.18em] text-[#9A857E]">
              Chapters & Months
            </p>
          </div>
          <div className="rounded-xl bg-[#FAF6F0]/80 px-3 py-2.5">
            <p className="font-editorial text-2xl font-semibold text-[#261C1A] sm:text-3xl">
              {metrics.days.toLocaleString()}
            </p>
            <p className="font-body text-[10px] font-medium uppercase tracking-[0.18em] text-[#9A857E]">
              Sunrises Shared
            </p>
          </div>
          <div className="rounded-xl bg-[#FAF6F0]/80 px-3 py-2.5">
            <p className="font-editorial text-2xl font-semibold tabular-nums text-[#C69C6D] sm:text-3xl">
              {metrics.seconds.toLocaleString()}
            </p>
            <p className="font-body text-[10px] font-medium uppercase tracking-[0.18em] text-[#9A857E]">
              Seconds Making Magic
            </p>
          </div>
        </motion.div>

        {/* Scroll Cue */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.0, duration: 0.8 }}
          className="mt-10"
        >
          <a
            href="#memories"
            className="group inline-flex flex-col items-center gap-2 font-body text-xs font-medium uppercase tracking-[0.2em] text-[#6B5853] transition-colors hover:text-[#8E3B46]"
          >
            <span>Open Your Chapters</span>
            <motion.span
              animate={{ y: [0, 6, 0] }}
              transition={{ duration: 1.8, repeat: Infinity, ease: "easeInOut" }}
              className="flex h-9 w-9 items-center justify-center rounded-full border border-[#E2D2C2] bg-[#FFFDF9] shadow-xs group-hover:border-[#8E3B46]/40"
            >
              <ArrowDown className="h-4 w-4 text-[#8E3B46]" />
            </motion.span>
          </a>
        </motion.div>
      </div>
    </section>
  );
}
