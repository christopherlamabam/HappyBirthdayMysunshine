import { useEffect, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  AlertTriangle,
  Check,
  CheckCircle2,
  Copy,
  Download,
  FileDown,
  HardDrive,
  Heart,
  Image as ImageIcon,
  ImagePlus,
  Loader2,
  RotateCcw,
  Save,
  Sparkles,
  UploadCloud,
  X,
} from "lucide-react";
import {
  createShareableGiftUrl,
  type BirthdayGiftData,
  type SaveResult,
} from "../data/giftData";
import {
  dataUrlByteSize,
  formatBytes,
  optimizePhotos,
  type OptimizedPhoto,
} from "../utils/imageUtils";

interface CustomizeStudioModalProps {
  isOpen: boolean;
  data: BirthdayGiftData;
  onClose: () => void;
  onSave: (nextData: BirthdayGiftData) => SaveResult;
  onReset: () => void;
}

type TabKey = "basics" | "memories" | "reasons" | "letter" | "gift";

export function CustomizeStudioModal({
  isOpen,
  data,
  onClose,
  onSave,
  onReset,
}: CustomizeStudioModalProps) {
  const [draft, setDraft] = useState<BirthdayGiftData>(data);
  const [activeTab, setActiveTab] = useState<TabKey>("basics");
  const [copiedUrl, setCopiedUrl] = useState(false);
  const [copyNotice, setCopyNotice] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);
  const [isDragOver, setIsDragOver] = useState(false);
  const [uploadNotice, setUploadNotice] = useState<string | null>(null);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [saveError, setSaveError] = useState<string | null>(null);
  const [exportNotice, setExportNotice] = useState<string | null>(null);
  const [exporting, setExporting] = useState(false);

  const generalInputRef = useRef<HTMLInputElement>(null);
  const replaceInputRef = useRef<HTMLInputElement>(null);
  const pendingReplaceIndex = useRef<number | null>(null);

  useEffect(() => {
    if (isOpen) {
      setDraft(data);
      setUploadError(null);
      setSaveError(null);
      setExportNotice(null);
    }
  }, [isOpen, data]);

  // Reset notices when moving between tabs.
  useEffect(() => {
    setUploadNotice(null);
    setCopyNotice(null);
    setUploadError(null);
  }, [activeTab]);

  const handleSave = () => {
    const result = onSave(draft);
    if (!result.ok) {
      setSaveError(result.message ?? "This browser could not save your changes.");
      return;
    }
    setSaveError(null);
    onClose();
  };

  const commitDraft = (nextDraft: BirthdayGiftData): SaveResult => {
    setDraft(nextDraft);
    const result = onSave(nextDraft);
    if (!result.ok) {
      setSaveError(result.message ?? "This browser could not save your changes.");
    } else {
      setSaveError(null);
    }
    return result;
  };

  const hasEmbeddedPhotos = draft.memories.some((m) =>
    m.imageUrl.startsWith("data:")
  );

  const handleCopyLink = async () => {
    const result = onSave(draft);
    if (!result.ok) setSaveError(result.message ?? null);
    // Photos uploaded from a device cannot be transported safely inside a URL,
    // so keep remote URLs and let the downloadable page carry local photos.
    const shareable: BirthdayGiftData = hasEmbeddedPhotos
      ? {
          ...draft,
          memories: draft.memories.map((memory) =>
            memory.imageUrl.startsWith("data:")
              ? { ...memory, imageUrl: "" }
              : memory
          ),
        }
      : draft;
    const url = createShareableGiftUrl(shareable);
    try {
      await navigator.clipboard.writeText(url);
      setCopiedUrl(true);
      setCopyNotice(
        hasEmbeddedPhotos
          ? "Text link copied. Device-uploaded photos can’t fit inside a link — use “Download Gift Page” so the photos travel with it."
          : "Full gift link copied — send it to her and every detail will open exactly like this."
      );
      window.setTimeout(() => setCopiedUrl(false), 2800);
    } catch {
      window.prompt("Copy your personalized birthday gift link:", url);
    }
  };

  const handleDownloadConfig = () => {
    const fileText = `import type { BirthdayGiftData } from "./giftData";\n\nexport const CUSTOM_GIFT_DATA: BirthdayGiftData = ${JSON.stringify(
      draft,
      null,
      2
    )};\n`;
    const blob = new Blob([fileText], { type: "text/typescript" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "giftData.custom.ts";
    a.click();
    URL.revokeObjectURL(url);
  };

  const downloadBlob = (content: Blob, filename: string) => {
    const url = URL.createObjectURL(content);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    window.setTimeout(() => URL.revokeObjectURL(url), 4000);
  };

  /**
   * Downloads a fully self-contained copy of this keepsake with the current
   * text AND uploaded photos embedded — ideal for opening on another device.
   */
  const handleDownloadCompleteGift = async () => {
    if (exporting) return;
    setExporting(true);
    setUploadError(null);
    setUploadNotice(null);
    setExportNotice(null);

    const saveResult = onSave(draft);
    if (!saveResult.ok) setSaveError(saveResult.message ?? null);

    try {
      const response = await fetch(
        window.location.href.split("#")[0].split("?")[0],
        { cache: "no-store" }
      );
      if (!response.ok) throw new Error("The page could not be read.");
      let html = await response.text();

      if (/<script[^>]+type=["']module["'][^>]+src=/i.test(html)) {
        throw new Error(
          "The page is still in development mode. Run “npm run build” first, then download from the built site."
        );
      }
      if (!html.includes("</head>")) {
        throw new Error("This page structure could not be exported.");
      }

      const safeJson = JSON.stringify(draft)
        .replace(/</g, "\\u003c")
        .replace(/\u2028/g, "\\u2028")
        .replace(/\u2029/g, "\\u2029");
      const injection = `<script>window.__GIFT_DATA__ = ${safeJson};</script>`;
      html = html.replace("</head>", `${injection}</head>`);

      const safeName = (draft.recipientName || "birthday")
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, "-")
        .replace(/^-|-$/g, "");
      downloadBlob(
        new Blob([html], { type: "text/html;charset=utf-8" }),
        `birthday-gift-for-${safeName || "her"}.html`
      );

      const localCount = draft.memories.filter((m) =>
        m.imageUrl.startsWith("data:")
      ).length;
      setExportNotice(
        localCount > 0
          ? `✓ Downloaded a complete keepsake page with ${localCount} photo${
              localCount === 1 ? "" : "s"
            } embedded. Open the HTML file or send it directly to her.`
          : "✓ Downloaded a complete keepsake page. Open the HTML file anywhere or share it directly."
      );
    } catch (error) {
      setUploadError(
        error instanceof Error
          ? error.message
          : "The downloadable page could not be created. Try “Export TS” instead."
      );
    } finally {
      setExporting(false);
    }
  };

  const importPhotos = async (
    fileList: FileList | File[] | null,
    replaceIndex: number | null = null
  ) => {
    if (!fileList) return;
    const files = Array.from(fileList);
    if (files.length === 0) return;

    setUploading(true);
    setUploadError(null);
    setUploadNotice(null);

    const { photos, errors } = await optimizePhotos(
      replaceIndex === null ? files : files.slice(0, 1)
    );

    if (photos.length > 0) {
      // The original gallery is made entirely of sample stock photos. The
      // first upload replaces that entire gallery with her real pictures.
      const isSampleGallery = draft.memories.every(
        (memory) =>
          !memory.imageUrl || memory.imageUrl.includes("images.pexels.com")
      );

      let memories: BirthdayGiftData["memories"];

      if (replaceIndex !== null && draft.memories[replaceIndex]) {
        memories = [...draft.memories];
        memories[replaceIndex] = {
          ...memories[replaceIndex],
          imageUrl: photos[0].dataUrl,
        };
      } else if (isSampleGallery) {
        memories = photos.map((photo: OptimizedPhoto, photoIndex) => {
          const template = draft.memories[photoIndex];
          return {
            id: `mem-user-${Date.now()}-${photoIndex}`,
            imageUrl: photo.dataUrl,
            dateLabel: template?.dateLabel ?? "A Favorite Day",
            location: template?.location ?? "Somewhere With You",
            caption:
              template?.caption ?? "One of my favorite memories with you.",
            backStory:
              template?.backStory ??
              "Write the little story behind this photo—the details only the two of you remember.",
          };
        });
      } else {
        // Never overwrite photos she already has; append new keepsakes.
        memories = [
          ...draft.memories,
          ...photos.map((photo: OptimizedPhoto, photoIndex) => ({
            id: `mem-${Date.now()}-${photoIndex}`,
            imageUrl: photo.dataUrl,
            dateLabel: "A Favorite Day",
            location: "Somewhere With You",
            caption: "One of my favorite memories with you.",
            backStory:
              "Write the little story behind this photo—the details only the two of you remember.",
          })),
        ];
      }

      const addedBytes = photos.reduce(
        (total: number, photo: OptimizedPhoto) => total + photo.bytes,
        0
      );
      const addedCount = photos.length;
      const nextDraft: BirthdayGiftData = { ...draft, memories };
      const result = commitDraft(nextDraft);
      const storedNote = result.ok
        ? "saved on this device"
        : "held temporarily — check the storage note below";
      setUploadNotice(
        `✓ ${addedCount} photo${
          addedCount === 1 ? "" : "s"
        } optimized (${formatBytes(addedBytes)}) and ${storedNote}.`
      );
    }

    if (errors.length > 0) {
      setUploadError(errors.join(" "));
    }
    setUploading(false);
    if (generalInputRef.current) generalInputRef.current.value = "";
    if (replaceInputRef.current) replaceInputRef.current.value = "";
    pendingReplaceIndex.current = null;
  };

  const updateMemory = (
    idx: number,
    field: keyof BirthdayGiftData["memories"][number],
    value: string
  ) => {
    setDraft((prev) => {
      const next = [...prev.memories];
      next[idx] = { ...next[idx], [field]: value };
      return { ...prev, memories: next };
    });
  };

  const updateReason = (
    idx: number,
    field: "title" | "note" | "tag",
    value: string
  ) => {
    setDraft((prev) => {
      const next = [...prev.reasons];
      next[idx] = { ...next[idx], [field]: value };
      return { ...prev, reasons: next };
    });
  };

  const addMemory = () => {
    setDraft((prev) => ({
      ...prev,
      memories: [
        ...prev.memories,
        {
          id: `mem-${Date.now()}`,
          imageUrl:
            "https://images.pexels.com/photos/16399253/pexels-photo-16399253.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
          dateLabel: "A New Chapter",
          location: "Somewhere Special",
          caption: "Our next favorite memory…",
          backStory: "Write the little story you never want to forget here.",
        },
      ],
    }));
  };

  const removeMemory = (idx: number) => {
    setDraft((prev) => ({
      ...prev,
      memories: prev.memories.filter((_, i) => i !== idx),
    }));
  };

  const embeddedBytes = draft.memories.reduce(
    (total, memory) => total + dataUrlByteSize(memory.imageUrl),
    0
  );
  const embeddedPhotoCount = draft.memories.filter((memory) =>
    memory.imageUrl.startsWith("data:")
  ).length;
  const storagePercent = Math.min(
    100,
    Math.round((embeddedBytes / (4 * 1024 * 1024)) * 100)
  );
  const storageIsTight = embeddedBytes > 3 * 1024 * 1024;

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-center justify-center bg-[#1C1417]/75 p-4 backdrop-blur-sm"
        >
          <motion.div
            initial={{ opacity: 0, y: 24, scale: 0.97 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 24, scale: 0.97 }}
            transition={{ duration: 0.3 }}
            className="flex max-h-[90vh] w-full max-w-4xl flex-col overflow-hidden rounded-2xl border border-[#DFCBB8] bg-[#FAF6F0] shadow-2xl"
          >
            {/* Hidden inputs used by every upload button */}
            <input
              ref={generalInputRef}
              type="file"
              accept="image/*,.jpg,.jpeg,.png,.webp,.gif,.avif,.heic,.heif"
              multiple
              className="hidden"
              onChange={(e) => importPhotos(e.target.files, null)}
            />
            <input
              ref={replaceInputRef}
              type="file"
              accept="image/*,.jpg,.jpeg,.png,.webp,.gif,.avif,.heic,.heif"
              className="hidden"
              onChange={(e) => {
                const idx = pendingReplaceIndex.current;
                if (idx !== null) importPhotos(e.target.files, idx);
              }}
            />

            {/* Header */}
            <div className="flex items-center justify-between border-b border-[#E5D5C5] bg-[#FFFDF9] px-6 py-4">
              <div>
                <div className="flex items-center gap-2">
                  <Sparkles className="h-4 w-4 text-[#8E3B46]" />
                  <h2 className="font-editorial text-2xl font-semibold text-[#261C1A]">
                    Personalize Her 22nd Birthday Gift
                  </h2>
                </div>
                <p className="mt-0.5 font-body text-xs text-[#6B5853]">
                  Customize every detail below, then preview live or copy a shareable gift link.
                </p>
              </div>

              <button
                type="button"
                onClick={onClose}
                className="rounded-full p-2 text-[#6B5853] transition-colors hover:bg-[#EFE2D7] hover:text-[#261C1A]"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {/* Tabs */}
            <div className="flex gap-1 overflow-x-auto border-b border-[#E5D5C5] bg-[#F5ECE2] px-6 py-2">
              {(
                [
                  { id: "basics", label: "Names & Hero" },
                  { id: "memories", label: "Photos · Upload" },
                  { id: "reasons", label: "22 Reasons" },
                  { id: "letter", label: "Love Letter" },
                  { id: "gift", label: "Birthday Voucher" },
                ] as const
              ).map((tab) => (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setActiveTab(tab.id)}
                  className={`whitespace-nowrap rounded-lg px-3.5 py-2 font-body text-xs font-medium transition-colors ${
                    activeTab === tab.id
                      ? "bg-[#8E3B46] text-white shadow-xs"
                      : "text-[#6B5853] hover:bg-[#FFFDF9] hover:text-[#261C1A]"
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            {/* Scrollable Body */}
            <div className="flex-1 overflow-y-auto p-6">
              {activeTab === "basics" && (
                <div className="grid gap-4 sm:grid-cols-2">
                  <label className="space-y-1.5">
                    <span className="font-body text-xs font-medium text-[#261C1A]">
                      Girlfriend’s First Name
                    </span>
                    <input
                      type="text"
                      value={draft.recipientName}
                      onChange={(e) =>
                        setDraft({ ...draft, recipientName: e.target.value })
                      }
                      className="w-full rounded-xl border border-[#DFCBB8] bg-[#FFFDF9] px-3.5 py-2.5 text-sm focus:border-[#8E3B46] focus:outline-none"
                    />
                  </label>

                  <label className="space-y-1.5">
                    <span className="font-body text-xs font-medium text-[#261C1A]">
                      Affectionate Nickname
                    </span>
                    <input
                      type="text"
                      value={draft.recipientNickname}
                      onChange={(e) =>
                        setDraft({ ...draft, recipientNickname: e.target.value })
                      }
                      className="w-full rounded-xl border border-[#DFCBB8] bg-[#FFFDF9] px-3.5 py-2.5 text-sm focus:border-[#8E3B46] focus:outline-none"
                    />
                  </label>

                  <label className="space-y-1.5">
                    <span className="font-body text-xs font-medium text-[#261C1A]">
                      Your Name (Sender)
                    </span>
                    <input
                      type="text"
                      value={draft.senderName}
                      onChange={(e) =>
                        setDraft({ ...draft, senderName: e.target.value })
                      }
                      className="w-full rounded-xl border border-[#DFCBB8] bg-[#FFFDF9] px-3.5 py-2.5 text-sm focus:border-[#8E3B46] focus:outline-none"
                    />
                  </label>

                  <label className="space-y-1.5">
                    <span className="font-body text-xs font-medium text-[#261C1A]">
                      Her Birthdate (Powers Live Counter)
                    </span>
                    <input
                      type="date"
                      value={draft.birthDate}
                      onChange={(e) =>
                        setDraft({ ...draft, birthDate: e.target.value })
                      }
                      className="w-full rounded-xl border border-[#DFCBB8] bg-[#FFFDF9] px-3.5 py-2.5 text-sm focus:border-[#8E3B46] focus:outline-none"
                    />
                  </label>

                  <label className="space-y-1.5 sm:col-span-2">
                    <span className="font-body text-xs font-medium text-[#261C1A]">
                      Birthday Date Label (e.g. Chapter XXII · May 14)
                    </span>
                    <input
                      type="text"
                      value={draft.birthdayDisplayDate}
                      onChange={(e) =>
                        setDraft({
                          ...draft,
                          birthdayDisplayDate: e.target.value,
                        })
                      }
                      className="w-full rounded-xl border border-[#DFCBB8] bg-[#FFFDF9] px-3.5 py-2.5 text-sm focus:border-[#8E3B46] focus:outline-none"
                    />
                  </label>

                  <label className="space-y-1.5 sm:col-span-2">
                    <span className="font-body text-xs font-medium text-[#261C1A]">
                      Envelope Front Line
                    </span>
                    <input
                      type="text"
                      value={draft.envelopeNote}
                      onChange={(e) =>
                        setDraft({ ...draft, envelopeNote: e.target.value })
                      }
                      className="w-full rounded-xl border border-[#DFCBB8] bg-[#FFFDF9] px-3.5 py-2.5 text-sm focus:border-[#8E3B46] focus:outline-none"
                    />
                  </label>

                  <label className="space-y-1.5 sm:col-span-2">
                    <span className="font-body text-xs font-medium text-[#261C1A]">
                      Hero Eyebrow / Small Header Line
                    </span>
                    <input
                      type="text"
                      value={draft.heroEyebrow}
                      onChange={(e) =>
                        setDraft({ ...draft, heroEyebrow: e.target.value })
                      }
                      className="w-full rounded-xl border border-[#DFCBB8] bg-[#FFFDF9] px-3.5 py-2.5 text-sm focus:border-[#8E3B46] focus:outline-none"
                    />
                  </label>

                  <label className="space-y-1.5 sm:col-span-2">
                    <span className="font-body text-xs font-medium text-[#261C1A]">
                      Hero Headline
                    </span>
                    <input
                      type="text"
                      value={draft.heroHeadline}
                      onChange={(e) =>
                        setDraft({ ...draft, heroHeadline: e.target.value })
                      }
                      className="w-full rounded-xl border border-[#DFCBB8] bg-[#FFFDF9] px-3.5 py-2.5 text-sm focus:border-[#8E3B46] focus:outline-none"
                    />
                  </label>

                  <label className="space-y-1.5 sm:col-span-2">
                    <span className="font-body text-xs font-medium text-[#261C1A]">
                      Hero Subtitle
                    </span>
                    <textarea
                      rows={3}
                      value={draft.heroSubtitle}
                      onChange={(e) =>
                        setDraft({ ...draft, heroSubtitle: e.target.value })
                      }
                      className="w-full rounded-xl border border-[#DFCBB8] bg-[#FFFDF9] px-3.5 py-2.5 text-sm focus:border-[#8E3B46] focus:outline-none"
                    />
                  </label>

                  <div className="mt-2 border-t border-[#E5D5C5] pt-4 sm:col-span-2">
                    <p className="font-editorial text-lg font-semibold text-[#8E3B46]">
                      Section Titles & Subtitles
                    </p>
                    <p className="font-body text-[11px] text-[#6B5853]">
                      Change the headline wording for each chapter of her page.
                    </p>
                  </div>

                  <label className="space-y-1.5 sm:col-span-2">
                    <span className="font-body text-xs font-medium text-[#261C1A]">
                      Memories Section Title
                    </span>
                    <input
                      type="text"
                      value={draft.memoriesHeading}
                      onChange={(e) =>
                        setDraft({ ...draft, memoriesHeading: e.target.value })
                      }
                      className="w-full rounded-xl border border-[#DFCBB8] bg-[#FFFDF9] px-3.5 py-2.5 text-sm focus:border-[#8E3B46] focus:outline-none"
                    />
                  </label>

                  <label className="space-y-1.5 sm:col-span-2">
                    <span className="font-body text-xs font-medium text-[#261C1A]">
                      Memories Section Subtitle
                    </span>
                    <textarea
                      rows={2}
                      value={draft.memoriesSubheading}
                      onChange={(e) =>
                        setDraft({
                          ...draft,
                          memoriesSubheading: e.target.value,
                        })
                      }
                      className="w-full rounded-xl border border-[#DFCBB8] bg-[#FFFDF9] px-3.5 py-2.5 text-sm focus:border-[#8E3B46] focus:outline-none"
                    />
                  </label>

                  <label className="space-y-1.5 sm:col-span-2">
                    <span className="font-body text-xs font-medium text-[#261C1A]">
                      22 Reasons Section Title
                    </span>
                    <input
                      type="text"
                      value={draft.reasonsHeading}
                      onChange={(e) =>
                        setDraft({ ...draft, reasonsHeading: e.target.value })
                      }
                      className="w-full rounded-xl border border-[#DFCBB8] bg-[#FFFDF9] px-3.5 py-2.5 text-sm focus:border-[#8E3B46] focus:outline-none"
                    />
                  </label>

                  <label className="space-y-1.5 sm:col-span-2">
                    <span className="font-body text-xs font-medium text-[#261C1A]">
                      22 Reasons Section Subtitle
                    </span>
                    <textarea
                      rows={2}
                      value={draft.reasonsSubheading}
                      onChange={(e) =>
                        setDraft({
                          ...draft,
                          reasonsSubheading: e.target.value,
                        })
                      }
                      className="w-full rounded-xl border border-[#DFCBB8] bg-[#FFFDF9] px-3.5 py-2.5 text-sm focus:border-[#8E3B46] focus:outline-none"
                    />
                  </label>

                  <label className="space-y-1.5 sm:col-span-2">
                    <span className="font-body text-xs font-medium text-[#261C1A]">
                      Make-a-Wish Section Title
                    </span>
                    <input
                      type="text"
                      value={draft.wishStageHeadline}
                      onChange={(e) =>
                        setDraft({
                          ...draft,
                          wishStageHeadline: e.target.value,
                        })
                      }
                      className="w-full rounded-xl border border-[#DFCBB8] bg-[#FFFDF9] px-3.5 py-2.5 text-sm focus:border-[#8E3B46] focus:outline-none"
                    />
                  </label>

                  <label className="space-y-1.5 sm:col-span-2">
                    <span className="font-body text-xs font-medium text-[#261C1A]">
                      Make-a-Wish Subtitle
                    </span>
                    <textarea
                      rows={2}
                      value={draft.wishStageSubheading}
                      onChange={(e) =>
                        setDraft({
                          ...draft,
                          wishStageSubheading: e.target.value,
                        })
                      }
                      className="w-full rounded-xl border border-[#DFCBB8] bg-[#FFFDF9] px-3.5 py-2.5 text-sm focus:border-[#8E3B46] focus:outline-none"
                    />
                  </label>
                </div>
              )}

              {activeTab === "memories" && (
                <div className="space-y-5">
                  {/* Device Photo Uploader */}
                  <div
                    onDragOver={(e) => {
                      e.preventDefault();
                      setIsDragOver(true);
                    }}
                    onDragLeave={() => setIsDragOver(false)}
                    onDrop={(e) => {
                      e.preventDefault();
                      setIsDragOver(false);
                      void importPhotos(e.dataTransfer.files, null);
                    }}
                    className={`relative rounded-2xl border-2 border-dashed p-5 text-center transition-colors sm:p-6 ${
                      isDragOver
                        ? "border-[#8E3B46] bg-[#8E3B46]/5"
                        : "border-[#C69C6D]/55 bg-[#FFFDF9]"
                    }`}
                  >
                    <div className="mx-auto flex h-11 w-11 items-center justify-center rounded-full border border-[#C69C6D]/40 bg-[#FAF6F0] text-[#8E3B46]">
                      {uploading ? (
                        <Loader2 className="h-5 w-5 animate-spin" />
                      ) : (
                        <UploadCloud className="h-5 w-5" />
                      )}
                    </div>

                    <p className="mt-3 font-editorial text-xl font-semibold text-[#261C1A]">
                      {uploading ? "Polishing your photos…" : "Upload photos from your device"}
                    </p>
                    <p className="mx-auto mt-1 max-w-md font-body text-[11px] leading-relaxed text-[#6B5853]">
                      Click to browse or drag &amp; drop your pictures here. They are automatically
                      resized and compressed, then saved on this device. Your first batch replaces the
                      sample gallery; later uploads are added as new cards. Use a card’s own Upload
                      button to swap just that one.
                    </p>

                    <button
                      type="button"
                      onClick={() => generalInputRef.current?.click()}
                      disabled={uploading}
                      className="mt-4 inline-flex items-center gap-2 rounded-full bg-[#8E3B46] px-5 py-2.5 font-body text-xs font-semibold uppercase tracking-[0.14em] text-white shadow-sm transition-colors hover:bg-[#752D37] disabled:opacity-60"
                    >
                      {uploading ? (
                        <>
                          <Loader2 className="h-3.5 w-3.5 animate-spin" />
                          Optimizing…
                        </>
                      ) : (
                        <>
                          <ImagePlus className="h-3.5 w-3.5" />
                          Choose Photos From Device
                        </>
                      )}
                    </button>

                    <p className="mt-2 font-body text-[10px] text-[#9A857E]">
                      JPG · PNG · WEBP · GIF · AVIF · up to 30 MB each. iPhone HEIC photos: export or
                      save as JPG first.
                    </p>
                  </div>

                  {/* Upload feedback */}
                  {uploadNotice && (
                    <div className="flex items-start gap-2.5 rounded-xl border border-[#8BA58A]/45 bg-[#F2F7EF] px-4 py-3 text-xs text-[#3F5B3D]">
                      <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0" />
                      <span>{uploadNotice}</span>
                    </div>
                  )}
                  {uploadError && (
                    <div className="flex items-start gap-2.5 rounded-xl border border-[#B4574F]/40 bg-[#FBF0ED] px-4 py-3 text-xs text-[#8E3B46]">
                      <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />
                      <span>{uploadError}</span>
                    </div>
                  )}
                  {saveError && (
                    <div className="flex items-start gap-3 rounded-xl border border-[#B4574F]/40 bg-[#FBF0ED] px-4 py-3 text-xs text-[#8E3B46]">
                      <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />
                      <div className="flex-1">
                        <p className="font-semibold">Local save warning</p>
                        <p className="mt-0.5 leading-relaxed">{saveError}</p>
                        <button
                          type="button"
                          onClick={handleDownloadCompleteGift}
                          className="mt-2 inline-flex items-center gap-1.5 rounded-full border border-[#8E3B46]/40 bg-[#FFFDF9] px-3 py-1.5 font-medium text-[#8E3B46]"
                        >
                          <FileDown className="h-3.5 w-3.5" />
                          Download Gift With Photos Instead
                        </button>
                      </div>
                    </div>
                  )}

                  {/* Storage meter */}
                  <div className="rounded-xl border border-[#E5D5C5] bg-[#FFFDF9] p-4">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <span className="inline-flex items-center gap-1.5 font-body text-[11px] font-medium text-[#261C1A]">
                        <HardDrive className="h-3.5 w-3.5 text-[#C69C6D]" />
                        {embeddedPhotoCount} uploaded photo
                        {embeddedPhotoCount === 1 ? "" : "s"} · {formatBytes(embeddedBytes)}
                      </span>
                      <span className="font-body text-[10px] text-[#9A857E]">
                        Browser keeps ~5 MB
                      </span>
                    </div>
                    <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-[#EFE2D7]">
                      <div
                        className={`h-full rounded-full transition-all duration-500 ${
                          storageIsTight
                            ? "bg-gradient-to-r from-[#D1913F] to-[#B4574F]"
                            : "bg-gradient-to-r from-[#C69C6D] to-[#8E3B46]"
                        }`}
                        style={{ width: `${Math.max(storagePercent, embeddedBytes > 0 ? 3 : 0)}%` }}
                      />
                    </div>
                    <p className="mt-2 font-body text-[10px] leading-relaxed text-[#6B5853]">
                      {storageIsTight
                        ? "Storage is getting full. Download the complete gift page below so your photos live in the file, or replace a Polaroid with a smaller picture."
                        : "Photos are stored privately in this browser. When you are finished, click “Download Gift Page” below to create a portable keepsake with every photo embedded."}
                    </p>
                  </div>

                  <div className="rounded-xl border border-[#C69C6D]/40 bg-[#FFFDF9] p-3.5 text-xs text-[#6B5853]">
                    <strong className="text-[#8E3B46]">Prefer a hosted image?</strong>{" "}
                    You can also paste a direct image address into any Polaroid below (from Cloudinary,
                    Imgur, etc.). A web address is ideal if you plan to share a text link.
                  </div>

                  {draft.memories.map((mem, idx) => (
                    <div
                      key={mem.id}
                      className="rounded-xl border border-[#E5D5C5] bg-[#FFFDF9] p-4 space-y-3"
                    >
                      <div className="flex items-center justify-between gap-3">
                        <div className="flex min-w-0 items-center gap-2.5">
                          {mem.imageUrl ? (
                            <img
                              src={mem.imageUrl}
                              alt=""
                              onError={(e) => {
                                e.currentTarget.style.opacity = "0.2";
                              }}
                              className="h-10 w-10 shrink-0 rounded-md border border-[#DFCBB8] object-cover"
                            />
                          ) : (
                            <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-md border border-[#DFCBB8] bg-[#FAF6F0] text-[#C69C6D]">
                              <ImageIcon className="h-4 w-4" />
                            </span>
                          )}
                          <div className="min-w-0">
                            <span className="inline-flex items-center gap-1.5 font-editorial text-lg font-semibold text-[#8E3B46]">
                              Polaroid #{idx + 1}
                            </span>
                            <p className="truncate font-body text-[11px] text-[#9A857E]">
                              {mem.location || "No location yet"}
                            </p>
                          </div>
                        </div>

                        <div className="flex shrink-0 items-center gap-1.5">
                          <button
                            type="button"
                            onClick={() => {
                              pendingReplaceIndex.current = idx;
                              replaceInputRef.current?.click();
                            }}
                            disabled={uploading}
                            title={`Upload a photo for Polaroid #${idx + 1}`}
                            className="inline-flex items-center gap-1 rounded-full border border-[#8E3B46]/35 bg-[#FFFDF9] px-2.5 py-1 font-body text-[10px] font-medium text-[#8E3B46] transition-colors hover:bg-[#8E3B46] hover:text-white disabled:opacity-50"
                          >
                            {uploading && pendingReplaceIndex.current === idx ? (
                              <Loader2 className="h-3 w-3 animate-spin" />
                            ) : (
                              <UploadCloud className="h-3 w-3" />
                            )}
                            Upload
                          </button>
                          <button
                            type="button"
                            onClick={() => removeMemory(idx)}
                            title="Remove this Polaroid"
                            className="inline-flex items-center gap-1 rounded-full border border-[#DFCBB8] px-2.5 py-1 font-body text-[10px] text-[#6B5853] transition-colors hover:border-[#8E3B46]/40 hover:text-[#8E3B46]"
                          >
                            <X className="h-3 w-3" /> Remove
                          </button>
                        </div>
                      </div>

                      <div className="grid gap-3 sm:grid-cols-2">
                        <input
                          type="text"
                          value={mem.imageUrl}
                          onChange={(e) =>
                            updateMemory(idx, "imageUrl", e.target.value)
                          }
                          placeholder="Image URL"
                          className="rounded-lg border border-[#DFCBB8] bg-[#FAF6F0] px-3 py-2 text-xs sm:col-span-2"
                        />
                        <input
                          type="text"
                          value={mem.dateLabel}
                          onChange={(e) =>
                            updateMemory(idx, "dateLabel", e.target.value)
                          }
                          placeholder="Date Label"
                          className="rounded-lg border border-[#DFCBB8] bg-[#FAF6F0] px-3 py-2 text-xs"
                        />
                        <input
                          type="text"
                          value={mem.location}
                          onChange={(e) =>
                            updateMemory(idx, "location", e.target.value)
                          }
                          placeholder="Location"
                          className="rounded-lg border border-[#DFCBB8] bg-[#FAF6F0] px-3 py-2 text-xs"
                        />
                        <input
                          type="text"
                          value={mem.caption}
                          onChange={(e) =>
                            updateMemory(idx, "caption", e.target.value)
                          }
                          placeholder="Front Polaroid Caption"
                          className="rounded-lg border border-[#DFCBB8] bg-[#FAF6F0] px-3 py-2 text-xs sm:col-span-2"
                        />
                        <textarea
                          rows={2}
                          value={mem.backStory}
                          onChange={(e) =>
                            updateMemory(idx, "backStory", e.target.value)
                          }
                          placeholder="Back-of-card secret story"
                          className="rounded-lg border border-[#DFCBB8] bg-[#FAF6F0] px-3 py-2 text-xs sm:col-span-2"
                        />
                      </div>
                    </div>
                  ))}

                  <button
                    type="button"
                    onClick={addMemory}
                    className="w-full rounded-xl border border-dashed border-[#C69C6D]/60 bg-[#FFFDF9] px-4 py-3 font-body text-xs font-medium uppercase tracking-[0.14em] text-[#8E3B46] transition-colors hover:border-[#8E3B46] hover:bg-[#8E3B46]/5"
                  >
                    + Add Another Polaroid
                  </button>
                </div>
              )}

              {activeTab === "reasons" && (
                <div className="space-y-3">
                  {draft.reasons.map((reason, idx) => (
                    <div
                      key={reason.number}
                      className="grid gap-2 rounded-xl border border-[#E5D5C5] bg-[#FFFDF9] p-3.5 sm:grid-cols-[60px_1fr_130px]"
                    >
                      <div className="flex items-center gap-1 font-editorial text-xl font-semibold text-[#8E3B46]">
                        <Heart className="h-3.5 w-3.5 fill-[#8E3B46]" />
                        {String(reason.number).padStart(2, "0")}
                      </div>
                      <input
                        type="text"
                        value={reason.title}
                        onChange={(e) =>
                          updateReason(idx, "title", e.target.value)
                        }
                        placeholder="Title"
                        className="rounded-lg border border-[#DFCBB8] bg-[#FAF6F0] px-3 py-1.5 text-xs font-medium"
                      />
                      <input
                        type="text"
                        value={reason.tag}
                        onChange={(e) =>
                          updateReason(idx, "tag", e.target.value)
                        }
                        placeholder="Tag"
                        className="rounded-lg border border-[#DFCBB8] bg-[#FAF6F0] px-3 py-1.5 text-xs"
                      />
                      <textarea
                        rows={2}
                        value={reason.note}
                        onChange={(e) =>
                          updateReason(idx, "note", e.target.value)
                        }
                        placeholder="Why you love this about her..."
                        className="rounded-lg border border-[#DFCBB8] bg-[#FAF6F0] px-3 py-1.5 text-xs sm:col-span-3"
                      />
                    </div>
                  ))}
                </div>
              )}

              {activeTab === "letter" && (
                <div className="space-y-4">
                  <label className="block space-y-1.5">
                    <span className="font-body text-xs font-medium">
                      Letter Section Headline
                    </span>
                    <input
                      type="text"
                      value={draft.letterHeading}
                      onChange={(e) =>
                        setDraft({ ...draft, letterHeading: e.target.value })
                      }
                      className="w-full rounded-xl border border-[#DFCBB8] bg-[#FFFDF9] px-3.5 py-2 text-sm"
                    />
                  </label>

                  <div className="grid gap-4 sm:grid-cols-2">
                    <label className="space-y-1.5">
                      <span className="font-body text-xs font-medium">
                        Letter Date Stamp
                      </span>
                      <input
                        type="text"
                        value={draft.letterDate}
                        onChange={(e) =>
                          setDraft({ ...draft, letterDate: e.target.value })
                        }
                        className="w-full rounded-xl border border-[#DFCBB8] bg-[#FFFDF9] px-3.5 py-2 text-sm"
                      />
                    </label>
                    <label className="space-y-1.5">
                      <span className="font-body text-xs font-medium">
                        Greeting Line
                      </span>
                      <input
                        type="text"
                        value={draft.letterGreeting}
                        onChange={(e) =>
                          setDraft({ ...draft, letterGreeting: e.target.value })
                        }
                        className="w-full rounded-xl border border-[#DFCBB8] bg-[#FFFDF9] px-3.5 py-2 text-sm"
                      />
                    </label>
                  </div>

                  <label className="block space-y-1.5">
                    <span className="font-body text-xs font-medium">
                      Letter Body (Separate paragraphs with a blank line)
                    </span>
                    <textarea
                      rows={10}
                      value={draft.letterParagraphs.join("\n\n")}
                      onChange={(e) =>
                        setDraft({
                          ...draft,
                          letterParagraphs: e.target.value
                            .split(/\n\s*\n/)
                            .filter((p) => p.trim().length > 0),
                        })
                      }
                      className="w-full rounded-xl border border-[#DFCBB8] bg-[#FFFDF9] px-4 py-3 text-sm leading-relaxed"
                    />
                  </label>

                  <label className="block space-y-1.5">
                    <span className="font-body text-xs font-medium">
                      Sign-Off Line
                    </span>
                    <input
                      type="text"
                      value={draft.letterClosing}
                      onChange={(e) =>
                        setDraft({ ...draft, letterClosing: e.target.value })
                      }
                      className="w-full rounded-xl border border-[#DFCBB8] bg-[#FFFDF9] px-3.5 py-2 text-sm"
                    />
                  </label>
                </div>
              )}

              {activeTab === "gift" && (
                <div className="space-y-4">
                  <label className="block space-y-1.5">
                    <span className="font-body text-xs font-medium">
                      Gift Voucher Title
                    </span>
                    <input
                      type="text"
                      value={draft.coupon.title}
                      onChange={(e) =>
                        setDraft({
                          ...draft,
                          coupon: { ...draft.coupon, title: e.target.value },
                        })
                      }
                      className="w-full rounded-xl border border-[#DFCBB8] bg-[#FFFDF9] px-3.5 py-2.5 text-sm"
                    />
                  </label>

                  <label className="block space-y-1.5">
                    <span className="font-body text-xs font-medium">
                      Gift Description
                    </span>
                    <textarea
                      rows={3}
                      value={draft.coupon.subtitle}
                      onChange={(e) =>
                        setDraft({
                          ...draft,
                          coupon: { ...draft.coupon, subtitle: e.target.value },
                        })
                      }
                      className="w-full rounded-xl border border-[#DFCBB8] bg-[#FFFDF9] px-3.5 py-2.5 text-sm"
                    />
                  </label>

                  <div className="grid gap-4 sm:grid-cols-2">
                    <label className="space-y-1.5">
                      <span className="font-body text-xs font-medium">
                        Date / Timing
                      </span>
                      <input
                        type="text"
                        value={draft.coupon.dateText}
                        onChange={(e) =>
                          setDraft({
                            ...draft,
                            coupon: { ...draft.coupon, dateText: e.target.value },
                          })
                        }
                        className="w-full rounded-xl border border-[#DFCBB8] bg-[#FFFDF9] px-3.5 py-2.5 text-sm"
                      />
                    </label>
                    <label className="space-y-1.5">
                      <span className="font-body text-xs font-medium">
                        Place / Dress Code
                      </span>
                      <input
                        type="text"
                        value={draft.coupon.locationText}
                        onChange={(e) =>
                          setDraft({
                            ...draft,
                            coupon: {
                              ...draft.coupon,
                              locationText: e.target.value,
                            },
                          })
                        }
                        className="w-full rounded-xl border border-[#DFCBB8] bg-[#FFFDF9] px-3.5 py-2.5 text-sm"
                      />
                    </label>
                  </div>

                  <label className="block space-y-1.5">
                    <span className="font-body text-xs font-medium">
                      Bonus Promise
                    </span>
                    <input
                      type="text"
                      value={draft.coupon.secretPromise}
                      onChange={(e) =>
                        setDraft({
                          ...draft,
                          coupon: {
                            ...draft.coupon,
                            secretPromise: e.target.value,
                          },
                        })
                      }
                      className="w-full rounded-xl border border-[#DFCBB8] bg-[#FFFDF9] px-3.5 py-2.5 text-sm"
                    />
                  </label>
                </div>
              )}
            </div>

            {/* Status messages shared across every tab */}
            {(copyNotice || saveError || exportNotice) && (
              <div className="space-y-2 border-t border-[#E5D5C5] bg-[#FAF6F0] px-6 py-3">
                {copyNotice && (
                  <div className="flex items-start gap-2 text-xs text-[#3F5B3D]">
                    <CheckCircle2 className="mt-0.5 h-3.5 w-3.5 shrink-0" />
                    <span>{copyNotice}</span>
                  </div>
                )}
                {exportNotice && (
                  <div className="flex items-start gap-2 text-xs text-[#3F5B3D]">
                    <CheckCircle2 className="mt-0.5 h-3.5 w-3.5 shrink-0" />
                    <span>{exportNotice}</span>
                  </div>
                )}
                {saveError && (
                  <div className="flex items-start gap-2 text-xs text-[#8E3B46]">
                    <AlertTriangle className="mt-0.5 h-3.5 w-3.5 shrink-0" />
                    <span>{saveError}</span>
                  </div>
                )}
              </div>
            )}

            {/* Footer Actions */}
            <div className="flex flex-wrap items-center justify-between gap-3 border-t border-[#E5D5C5] bg-[#FFFDF9] px-6 py-4">
              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    onReset();
                    onClose();
                  }}
                  className="inline-flex items-center gap-1.5 rounded-full border border-[#DFCBB8] px-3.5 py-2 font-body text-xs text-[#6B5853] hover:bg-[#FAF6F0]"
                >
                  <RotateCcw className="h-3.5 w-3.5" /> Reset
                </button>
                <button
                  type="button"
                  onClick={handleDownloadConfig}
                  title="Download the content as a TypeScript data file"
                  className="inline-flex items-center gap-1.5 rounded-full border border-[#DFCBB8] px-3.5 py-2 font-body text-xs text-[#261C1A] hover:bg-[#FAF6F0]"
                >
                  <Download className="h-3.5 w-3.5" /> Export TS
                </button>
              </div>

              <div className="flex flex-wrap items-center gap-2.5">
                <button
                  type="button"
                  onClick={handleDownloadCompleteGift}
                  disabled={exporting}
                  title="Download a standalone HTML keepsake with your text and uploaded photos embedded"
                  className="inline-flex items-center gap-1.5 rounded-full border border-[#C69C6D] bg-[#FAF6F0] px-4 py-2 font-body text-xs font-semibold text-[#261C1A] transition-colors hover:border-[#8E3B46] hover:bg-[#8E3B46]/5 disabled:opacity-60"
                >
                  {exporting ? (
                    <>
                      <Loader2 className="h-3.5 w-3.5 animate-spin" /> Preparing…
                    </>
                  ) : (
                    <>
                      <FileDown className="h-3.5 w-3.5" /> Download Gift Page
                    </>
                  )}
                </button>

                <button
                  type="button"
                  onClick={handleCopyLink}
                  className="inline-flex items-center gap-1.5 rounded-full border border-[#8E3B46]/30 bg-[#FAF6F0] px-4 py-2 font-body text-xs font-medium text-[#8E3B46] hover:bg-[#8E3B46]/10"
                >
                  {copiedUrl ? (
                    <>
                      <Check className="h-3.5 w-3.5" /> Link Copied!
                    </>
                  ) : (
                    <>
                      <Copy className="h-3.5 w-3.5" /> Copy Shareable Gift Link
                    </>
                  )}
                </button>

                <button
                  type="button"
                  onClick={handleSave}
                  className="inline-flex items-center gap-1.5 rounded-full bg-[#8E3B46] px-5 py-2 font-body text-xs font-semibold text-white shadow-sm hover:bg-[#752D37]"
                >
                  <Save className="h-3.5 w-3.5" />
                  Apply & Preview
                </button>
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
