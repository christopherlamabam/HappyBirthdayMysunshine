import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  ChevronLeft,
  ChevronRight,
  Heart,
  MapPin,
  Pause,
  Play,
  RotateCw,
  X,
} from "lucide-react";
import type { MemoryItem } from "../data/giftData";
import { soundEngine } from "../utils/soundEngine";

interface MemoriesGalleryProps {
  heading: string;
  subheading: string;
  memories: MemoryItem[];
  isMusicPlaying: boolean;
}

export function MemoriesGallery({
  heading,
  subheading,
  memories,
  isMusicPlaying,
}: MemoriesGalleryProps) {
  const [flippedIds, setFlippedIds] = useState<Record<string, boolean>>({});
  const [cinemaIndex, setCinemaIndex] = useState<number | null>(null);
  const [cinemaAutoPlay, setCinemaAutoPlay] = useState(true);

  const toggleFlip = (id: string) => {
    if (isMusicPlaying) {
      soundEngine.playCardChime();
    }
    setFlippedIds((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  useEffect(() => {
    if (cinemaIndex === null || !cinemaAutoPlay) return;
    const timer = window.setInterval(() => {
      setCinemaIndex((prev) =>
        prev === null ? null : (prev + 1) % memories.length
      );
    }, 4500);
    return () => window.clearInterval(timer);
  }, [cinemaIndex, cinemaAutoPlay, memories.length]);

  const activeCinemaMemory =
    cinemaIndex !== null ? memories[cinemaIndex] : null;

  return (
    <section
      id="memories"
      className="relative mx-auto max-w-6xl px-4 py-24 sm:px-8 sm:py-32"
    >
      {/* Section Header */}
      <motion.div
        initial={{ opacity: 0, y: 24 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, amount: 0.3 }}
        transition={{ duration: 0.75 }}
        className="mx-auto max-w-2xl text-center"
      >
        <span className="font-body text-xs font-medium uppercase tracking-[0.26em] text-[#8E3B46]">
          Chapter I · Our Polaroids
        </span>
        <h2 className="mt-3 font-editorial text-4xl font-medium text-[#261C1A] sm:text-5xl">
          {heading}
        </h2>
        <p className="mt-4 font-body text-base text-[#6B5853]">{subheading}</p>

        <div className="mt-6 flex justify-center">
          <button
            type="button"
            onClick={() => {
              setCinemaIndex(0);
              setCinemaAutoPlay(true);
            }}
            className="inline-flex items-center gap-2 rounded-full border border-[#C69C6D]/60 bg-[#FFFDF9] px-5 py-2.5 font-body text-xs font-medium uppercase tracking-[0.14em] text-[#261C1A] shadow-xs transition-all hover:border-[#8E3B46] hover:bg-[#8E3B46] hover:text-white"
          >
            <Play className="h-3.5 w-3.5 fill-current" />
            Watch Memory Reel
          </button>
        </div>
      </motion.div>

      {/* Polaroid Grid */}
      <div className="mt-14 grid gap-8 sm:grid-cols-2 lg:grid-cols-3 lg:gap-10">
        {memories.map((memory, index) => {
          const isFlipped = Boolean(flippedIds[memory.id]);
          const tiltDeg = index % 2 === 0 ? -1.6 : 1.5;

          return (
            <motion.div
              key={memory.id}
              initial={{ opacity: 0, y: 36, rotate: tiltDeg }}
              whileInView={{ opacity: 1, y: 0, rotate: tiltDeg }}
              whileHover={{ rotate: 0, y: -6 }}
              viewport={{ once: true, amount: 0.2 }}
              transition={{
                duration: 0.7,
                delay: (index % 3) * 0.1,
                ease: [0.22, 1, 0.36, 1],
              }}
              className="relative perspective-1200"
            >
              {/* Washi Tape Accent */}
              <div
                aria-hidden="true"
                className="pointer-events-none absolute -top-3 left-1/2 z-20 h-6 w-24 -translate-x-1/2 -rotate-2 rounded-xs border border-[#E6D4BC]/60 bg-[#EFE2D0]/85 shadow-xs backdrop-blur-xs"
              />

              {/* 3D Flipping Card */}
              <div
                onClick={() => toggleFlip(memory.id)}
                role="button"
                tabIndex={0}
                onKeyDown={(e) => {
                  if (e.key === "Enter" || e.key === " ") {
                    e.preventDefault();
                    toggleFlip(memory.id);
                  }
                }}
                aria-label={`Polaroid memory: ${memory.caption}. Tap to flip.`}
                className="group relative h-[430px] w-full cursor-pointer select-none preserve-3d transition-transform duration-700"
                style={{
                  transform: isFlipped ? "rotateY(180deg)" : "rotateY(0deg)",
                }}
              >
                {/* FRONT SIDE (Photo Polaroid) */}
                <div className="absolute inset-0 flex flex-col rounded-xl border border-[#E6D7C8] bg-[#FFFDF9] p-3.5 pb-5 shadow-[0_20px_45px_-20px_rgba(38,28,26,0.2)] backface-hidden">
                  <div className="relative aspect-[4/3] w-full overflow-hidden rounded-sm bg-[#EFE2D7]">
                    {memory.imageUrl ? (
                      <img
                        src={memory.imageUrl}
                        alt={memory.caption}
                        loading="lazy"
                        onError={(e) => {
                          e.currentTarget.style.opacity = "0";
                        }}
                        className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
                      />
                    ) : (
                      <div className="flex h-full w-full flex-col items-center justify-center gap-2 bg-[radial-gradient(circle_at_50%_40%,#FBF2E7,#E8D3C2)] text-[#8E3B46]/60">
                        <Heart className="h-8 w-8 fill-[#8E3B46]/15" />
                        <span className="font-handwritten text-xl">
                          Our favorite moment
                        </span>
                      </div>
                    )}
                    <div className="absolute inset-0 bg-gradient-to-t from-[#261C1A]/25 via-transparent to-transparent" />
                    <span className="absolute bottom-2.5 left-2.5 inline-flex items-center gap-1 rounded-full bg-[#FFFDF9]/90 px-2.5 py-1 font-body text-[10px] font-medium text-[#261C1A] backdrop-blur-xs">
                      <MapPin className="h-3 w-3 text-[#8E3B46]" />
                      {memory.location}
                    </span>
                  </div>

                  <div className="mt-4 flex flex-1 flex-col justify-between px-1">
                    <div>
                      <p className="font-body text-[10px] font-medium uppercase tracking-[0.2em] text-[#9A857E]">
                        {memory.dateLabel}
                      </p>
                      <p className="mt-1.5 font-handwritten text-2xl leading-snug text-[#261C1A]">
                        {memory.caption}
                      </p>
                    </div>

                    <div className="mt-3 flex items-center justify-between border-t border-[#F0E5DA] pt-2.5 text-[11px] text-[#8E3B46]/80">
                      <span className="font-body font-medium">
                        Read the note on the back
                      </span>
                      <RotateCw className="h-3.5 w-3.5 transition-transform duration-300 group-hover:rotate-45" />
                    </div>
                  </div>
                </div>

                {/* BACK SIDE (Handwritten Story Note) */}
                <div className="absolute inset-0 flex flex-col justify-between rounded-xl border border-[#DFCBB8] bg-gradient-to-br from-[#FFFDF9] to-[#F7EFE4] p-7 shadow-[0_20px_45px_-20px_rgba(38,28,26,0.22)] backface-hidden rotate-y-180">
                  <div>
                    <div className="flex items-center justify-between border-b border-[#E5D5C5] pb-3">
                      <span className="font-body text-[10px] font-medium uppercase tracking-[0.2em] text-[#8E3B46]">
                        {memory.dateLabel}
                      </span>
                      <span className="font-editorial text-sm italic text-[#C69C6D]">
                        Behind the Frame
                      </span>
                    </div>

                    <p className="mt-6 font-handwritten text-[26px] leading-relaxed text-[#261C1A]">
                      “{memory.backStory}”
                    </p>
                  </div>

                  <div className="flex items-center justify-between border-t border-[#E5D5C5] pt-3 text-xs text-[#6B5853]">
                    <span>{memory.location}</span>
                    <span className="inline-flex items-center gap-1 font-medium text-[#8E3B46]">
                      <RotateCw className="h-3.5 w-3.5" />
                      Flip back
                    </span>
                  </div>
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* Cinema Story Reel Lightbox Modal */}
      <AnimatePresence>
        {activeCinemaMemory && cinemaIndex !== null && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center bg-[#1C1417]/92 p-4 backdrop-blur-md"
          >
            <motion.div
              initial={{ scale: 0.94, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.94, opacity: 0 }}
              transition={{ duration: 0.35 }}
              className="relative w-full max-w-3xl overflow-hidden rounded-2xl border border-[#E8C89B]/20 bg-[#251B1E] p-4 shadow-2xl sm:p-6"
            >
              {/* Top Controls */}
              <div className="mb-4 flex items-center justify-between text-[#FAF6F0]">
                <div>
                  <p className="font-body text-[10px] uppercase tracking-[0.22em] text-[#E8C89B]">
                    Memory Reel · {cinemaIndex + 1} / {memories.length}
                  </p>
                  <p className="font-editorial text-xl italic text-[#FAF6F0]">
                    {activeCinemaMemory.dateLabel}
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setCinemaAutoPlay((prev) => !prev)}
                    className="inline-flex items-center gap-1.5 rounded-full border border-[#E8C89B]/30 px-3 py-1.5 text-xs text-[#E8C89B] transition-colors hover:bg-[#E8C89B]/10"
                  >
                    {cinemaAutoPlay ? (
                      <>
                        <Pause className="h-3.5 w-3.5" /> Pause
                      </>
                    ) : (
                      <>
                        <Play className="h-3.5 w-3.5" /> Auto-Play
                      </>
                    )}
                  </button>
                  <button
                    type="button"
                    onClick={() => setCinemaIndex(null)}
                    aria-label="Close Memory Reel"
                    className="rounded-full border border-white/15 p-2 text-[#FAF6F0]/80 transition-colors hover:bg-white/10 hover:text-white"
                  >
                    <X className="h-4 w-4" />
                  </button>
                </div>
              </div>

              {/* Ken Burns Animated Frame */}
              <div className="relative aspect-[16/10] w-full overflow-hidden rounded-xl bg-black">
                {activeCinemaMemory.imageUrl ? (
                  <AnimatePresence mode="wait">
                    <motion.img
                      key={activeCinemaMemory.id}
                      src={activeCinemaMemory.imageUrl}
                      alt={activeCinemaMemory.caption}
                      initial={{ opacity: 0, scale: 1.02 }}
                      animate={{ opacity: 1, scale: 1.1 }}
                      exit={{ opacity: 0 }}
                      transition={{
                        opacity: { duration: 0.7 },
                        scale: { duration: 5.2, ease: "linear" },
                      }}
                      className="h-full w-full object-cover"
                    />
                  </AnimatePresence>
                ) : (
                  <div className="flex h-full w-full flex-col items-center justify-center gap-3 bg-[radial-gradient(circle_at_50%_40%,#4A3330,#1C1417)] text-[#E8C89B]">
                    <Heart className="h-10 w-10 fill-[#E8C89B]/20" />
                    <span className="font-handwritten text-3xl">
                      {activeCinemaMemory.caption}
                    </span>
                  </div>
                )}

                <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-[#1C1417] via-transparent to-transparent" />

                <div className="absolute inset-x-6 bottom-5 text-white">
                  <p className="font-handwritten text-2xl sm:text-3xl">
                    {activeCinemaMemory.caption}
                  </p>
                  <p className="mt-1 max-w-xl font-body text-xs text-white/75 sm:text-sm">
                    {activeCinemaMemory.backStory}
                  </p>
                </div>
              </div>

              {/* Bottom Navigation Dots & Arrows */}
              <div className="mt-4 flex items-center justify-between">
                <button
                  type="button"
                  onClick={() =>
                    setCinemaIndex(
                      (cinemaIndex - 1 + memories.length) % memories.length
                    )
                  }
                  className="inline-flex items-center gap-1 rounded-full border border-white/15 px-3.5 py-1.5 text-xs text-white/85 hover:bg-white/10"
                >
                  <ChevronLeft className="h-4 w-4" /> Previous
                </button>

                <div className="flex gap-1.5">
                  {memories.map((m, idx) => (
                    <button
                      key={m.id}
                      type="button"
                      aria-label={`Jump to memory ${idx + 1}`}
                      onClick={() => setCinemaIndex(idx)}
                      className={`h-2 rounded-full transition-all ${
                        idx === cinemaIndex
                          ? "w-6 bg-[#E8C89B]"
                          : "w-2 bg-white/25 hover:bg-white/45"
                      }`}
                    />
                  ))}
                </div>

                <button
                  type="button"
                  onClick={() =>
                    setCinemaIndex((cinemaIndex + 1) % memories.length)
                  }
                  className="inline-flex items-center gap-1 rounded-full border border-white/15 px-3.5 py-1.5 text-xs text-white/85 hover:bg-white/10"
                >
                  Next <ChevronRight className="h-4 w-4" />
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}
