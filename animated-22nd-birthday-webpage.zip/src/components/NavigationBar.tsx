import { motion, useScroll, useSpring } from "framer-motion";
import { Mail, Pencil, Volume2, VolumeX } from "lucide-react";

interface NavigationBarProps {
  recipientName: string;
  isMusicPlaying: boolean;
  onToggleMusic: () => void;
  onReplayEnvelope: () => void;
  onOpenStudio: () => void;
}

const NAV_ITEMS = [
  { label: "Memories", href: "#memories" },
  { label: "22 Reasons", href: "#reasons" },
  { label: "Love Letter", href: "#letter" },
  { label: "Make a Wish", href: "#wish" },
  { label: "Your Gift", href: "#gift" },
];

export function NavigationBar({
  recipientName,
  isMusicPlaying,
  onToggleMusic,
  onReplayEnvelope,
  onOpenStudio,
}: NavigationBarProps) {
  const { scrollYProgress } = useScroll();
  const scaleX = useSpring(scrollYProgress, {
    stiffness: 140,
    damping: 24,
    restDelta: 0.001,
  });

  return (
    <motion.header
      initial={{ y: -24, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.8, delay: 0.3, ease: [0.22, 1, 0.36, 1] }}
      className="fixed inset-x-0 top-0 z-40 border-b border-[#E5D5C5]/60 bg-[#FAF6F0]/82 backdrop-blur-md"
    >
      {/* Golden Scroll Reading Progress Hairline */}
      <motion.div
        style={{ scaleX }}
        className="absolute inset-x-0 bottom-0 h-[2px] origin-left bg-gradient-to-r from-[#C69C6D] via-[#8E3B46] to-[#C69C6D]"
      />

      <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3 sm:px-8">
        {/* Left Monogram */}
        <a
          href="#top"
          className="flex items-center gap-2.5 text-[#261C1A] transition-opacity hover:opacity-80"
        >
          <span className="flex h-8 w-8 items-center justify-center rounded-full border border-[#C69C6D]/60 bg-[#FFFDF9] font-editorial text-sm font-semibold italic text-[#8E3B46] shadow-xs">
            22
          </span>
          <span className="font-editorial text-lg font-medium tracking-wide">
            For {recipientName}
          </span>
        </a>

        {/* Center Chapter Links (Desktop) */}
        <nav className="hidden items-center gap-6 md:flex">
          {NAV_ITEMS.map((item) => (
            <a
              key={item.href}
              href={item.href}
              className="font-body text-xs font-medium uppercase tracking-[0.14em] text-[#6B5853] transition-colors hover:text-[#8E3B46]"
            >
              {item.label}
            </a>
          ))}
        </nav>

        {/* Right Controls */}
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={onOpenStudio}
            title="Edit names, photos, letter & gift details"
            className="inline-flex items-center gap-1.5 rounded-full border border-[#8E3B46]/25 bg-[#FFFDF9] px-3 py-1.5 font-body text-[11px] font-medium text-[#8E3B46] transition-colors hover:border-[#8E3B46] hover:bg-[#8E3B46] hover:text-white"
          >
            <Pencil className="h-3.5 w-3.5" />
            <span className="hidden sm:inline">Edit Page</span>
          </button>

          <button
            type="button"
            onClick={onReplayEnvelope}
            title="Replay Wax-Seal Envelope"
            className="inline-flex h-8 w-8 items-center justify-center rounded-full border border-[#E2D2C2] bg-[#FFFDF9] text-[#6B5853] transition-colors hover:border-[#8E3B46]/40 hover:text-[#8E3B46]"
          >
            <Mail className="h-3.5 w-3.5" />
          </button>

          <button
            type="button"
            onClick={onToggleMusic}
            className={`inline-flex items-center gap-1.5 rounded-full border px-3 py-1.5 font-body text-[11px] font-medium tracking-wide transition-all ${
              isMusicPlaying
                ? "border-[#8E3B46]/30 bg-[#8E3B46] text-white shadow-sm"
                : "border-[#E2D2C2] bg-[#FFFDF9] text-[#6B5853] hover:border-[#C69C6D]"
            }`}
          >
            {isMusicPlaying ? (
              <>
                <Volume2 className="h-3.5 w-3.5" />
                <span className="hidden sm:inline">Music Box On</span>
              </>
            ) : (
              <>
                <VolumeX className="h-3.5 w-3.5" />
                <span className="hidden sm:inline">Chimes Off</span>
              </>
            )}
          </button>
        </div>
      </div>
    </motion.header>
  );
}
