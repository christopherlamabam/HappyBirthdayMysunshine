import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import confetti from "canvas-confetti";
import { Calendar, Check, Gift, MapPin, Sparkles, Star } from "lucide-react";
import type { GiftCoupon } from "../data/giftData";
import { soundEngine } from "../utils/soundEngine";

interface BirthdayGiftPassProps {
  recipientName: string;
  senderName: string;
  coupon: GiftCoupon;
  isMusicPlaying: boolean;
}

const CLAIMED_KEY = "birthday_keepsake_claimed_v1";
const WISH_KEY = "birthday_keepsake_wish_note_v1";

export function BirthdayGiftPass({
  recipientName,
  senderName,
  coupon,
  isMusicPlaying,
}: BirthdayGiftPassProps) {
  const [isClaimed, setIsClaimed] = useState(false);
  const [wishText, setWishText] = useState("");
  const [savedWish, setSavedWish] = useState<string | null>(null);

  useEffect(() => {
    try {
      setIsClaimed(window.localStorage.getItem(CLAIMED_KEY) === "true");
      const existingWish = window.localStorage.getItem(WISH_KEY);
      if (existingWish) {
        setSavedWish(existingWish);
        setWishText(existingWish);
      }
    } catch {
      // Ignore storage errors
    }
  }, []);

  const handleClaim = () => {
    if (isClaimed) return;
    setIsClaimed(true);
    try {
      window.localStorage.setItem(CLAIMED_KEY, "true");
    } catch {
      // Ignore
    }
    if (isMusicPlaying) {
      soundEngine.playCelebrationArpeggio();
    }
    confetti({
      particleCount: 70,
      spread: 75,
      origin: { y: 0.65 },
      colors: ["#8E3B46", "#C69C6D", "#E8C89B", "#FFFDF9"],
    });
  };

  const handleSaveWish = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = wishText.trim();
    if (!trimmed) return;
    setSavedWish(trimmed);
    try {
      window.localStorage.setItem(WISH_KEY, trimmed);
    } catch {
      // Ignore
    }
    if (isMusicPlaying) {
      soundEngine.playCardChime();
    }
  };

  return (
    <section
      id="gift"
      className="relative mx-auto max-w-5xl px-4 py-24 sm:px-8 sm:py-32"
    >
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, amount: 0.3 }}
        transition={{ duration: 0.7 }}
        className="text-center"
      >
        <span className="font-body text-xs font-medium uppercase tracking-[0.26em] text-[#8E3B46]">
          Chapter V · Your Surprise Pass
        </span>
        <h2 className="mt-3 font-editorial text-4xl font-medium text-[#261C1A] sm:text-5xl">
          One More Thing, {recipientName}
        </h2>
        <p className="mx-auto mt-3 max-w-lg font-body text-sm text-[#6B5853] sm:text-base">
          Because twenty-two deserves more than words on a screen—consider this officially yours whenever you’re ready.
        </p>
      </motion.div>

      {/* Luxury Perforated Birthday Ticket */}
      <motion.div
        initial={{ opacity: 0, y: 28 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, amount: 0.25 }}
        transition={{ duration: 0.85, ease: [0.22, 1, 0.36, 1] }}
        className="relative mx-auto mt-12 max-w-3xl overflow-hidden rounded-3xl border border-[#DFCBB8] bg-[#FFFDF9] shadow-[0_32px_70px_-24px_rgba(142,59,70,0.22)]"
      >
        {/* Top Champagne Gold Foil Header Strip */}
        <div className="relative overflow-hidden bg-gradient-to-r from-[#8E3B46] via-[#A34955] to-[#8E3B46] px-6 py-4 text-white sm:px-10">
          <div className="animate-foil-sweep pointer-events-none absolute inset-y-0 left-0 w-32 bg-gradient-to-r from-transparent via-white/25 to-transparent" />
          <div className="relative z-10 flex items-center justify-between gap-4">
            <div className="flex items-center gap-2.5">
              <Gift className="h-4 w-4 text-[#F5D6B8]" />
              <span className="font-body text-[11px] font-medium uppercase tracking-[0.22em] text-[#FAE8D4]">
                {coupon.eyebrow}
              </span>
            </div>
            <span className="font-editorial text-lg italic text-[#F5D6B8]">
              No. 022
            </span>
          </div>
        </div>

        {/* Ticket Body + Perforated Right Stub */}
        <div className="relative grid md:grid-cols-[1fr_230px]">
          {/* Left Main Pass Details */}
          <div className="relative p-7 sm:p-10">
            {/* Claimed Ink Stamp Overlay */}
            <AnimatePresence>
              {isClaimed && (
                <motion.div
                  initial={{ scale: 2.2, opacity: 0, rotate: -24 }}
                  animate={{ scale: 1, opacity: 1, rotate: -12 }}
                  transition={{ type: "spring", stiffness: 260, damping: 18 }}
                  className="pointer-events-none absolute right-6 top-6 z-20 rounded-xl border-2 border-[#8E3B46] bg-[#FFFDF9]/90 px-4 py-1.5 shadow-sm"
                >
                  <span className="font-editorial text-xl font-bold uppercase tracking-[0.18em] text-[#8E3B46]">
                    Claimed ♥
                  </span>
                </motion.div>
              )}
            </AnimatePresence>

            <h3 className="font-editorial text-3xl font-semibold text-[#261C1A] sm:text-4xl">
              {coupon.title}
            </h3>
            <p className="mt-3 font-body text-sm leading-relaxed text-[#6B5853] sm:text-[15px]">
              {coupon.subtitle}
            </p>

            <div className="mt-6 grid gap-3 sm:grid-cols-2">
              <div className="flex items-start gap-2.5 rounded-xl bg-[#FAF6F0] p-3.5">
                <Calendar className="mt-0.5 h-4 w-4 shrink-0 text-[#8E3B46]" />
                <div>
                  <p className="font-body text-[10px] font-medium uppercase tracking-[0.18em] text-[#9A857E]">
                    When
                  </p>
                  <p className="mt-0.5 font-body text-xs font-medium text-[#261C1A]">
                    {coupon.dateText}
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-2.5 rounded-xl bg-[#FAF6F0] p-3.5">
                <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-[#8E3B46]" />
                <div>
                  <p className="font-body text-[10px] font-medium uppercase tracking-[0.18em] text-[#9A857E]">
                    Where
                  </p>
                  <p className="mt-0.5 font-body text-xs font-medium text-[#261C1A]">
                    {coupon.locationText}
                  </p>
                </div>
              </div>
            </div>

            <div className="mt-5 rounded-xl border border-dashed border-[#C69C6D]/50 bg-[#FBF6EE] px-4 py-3">
              <p className="font-handwritten text-xl text-[#8E3B46]">
                Bonus promise: {coupon.secretPromise}
              </p>
            </div>
          </div>

          {/* Perforated Divider & Claim Stub */}
          <div className="relative flex flex-col items-center justify-between border-t border-dashed border-[#DFCBB8] bg-[#FAF4EC] p-7 text-center md:border-l md:border-t-0">
            {/* Semicircle Cutout Notches */}
            <div
              aria-hidden="true"
              className="absolute -top-3 left-6 hidden h-6 w-6 rounded-full border border-[#DFCBB8] bg-[#FAF6F0] md:-left-3 md:-top-3 md:block"
            />
            <div
              aria-hidden="true"
              className="absolute -bottom-3 left-6 hidden h-6 w-6 rounded-full border border-[#DFCBB8] bg-[#FAF6F0] md:-bottom-3 md:-left-3 md:block"
            />

            <div>
              <p className="font-body text-[10px] font-medium uppercase tracking-[0.22em] text-[#9A857E]">
                Issued By
              </p>
              <p className="mt-1 font-handwritten text-2xl text-[#261C1A]">
                {senderName}
              </p>
            </div>

            <div className="my-6">
              <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full border border-[#C69C6D]/50 bg-[#FFFDF9] shadow-xs">
                <Sparkles className="h-7 w-7 text-[#C69C6D]" />
              </div>
              <p className="mt-2 font-body text-[10px] uppercase tracking-[0.18em] text-[#9A857E]">
                Zero Expiration
              </p>
            </div>

            <button
              type="button"
              onClick={handleClaim}
              disabled={isClaimed}
              className={`w-full rounded-full px-5 py-3 font-body text-xs font-semibold uppercase tracking-[0.14em] transition-all ${
                isClaimed
                  ? "inline-flex items-center justify-center gap-1.5 border border-[#8E3B46]/30 bg-[#8E3B46]/10 text-[#8E3B46]"
                  : "bg-[#8E3B46] text-white shadow-md hover:bg-[#752D37] active:scale-[0.98]"
              }`}
            >
              {isClaimed ? (
                <>
                  <Check className="h-3.5 w-3.5" /> Redeemed
                </>
              ) : (
                "Claim Birthday Gift"
              )}
            </button>
          </div>
        </div>
      </motion.div>

      {/* Personal Year 22 Wish Vault */}
      <motion.div
        initial={{ opacity: 0, y: 24 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, amount: 0.25 }}
        transition={{ duration: 0.75, delay: 0.15 }}
        className="mx-auto mt-14 max-w-xl rounded-2xl border border-[#E5D5C5] bg-[#FFFDF9] p-6 text-center shadow-sm sm:p-8"
      >
        <div className="inline-flex items-center gap-1.5 text-[11px] font-medium uppercase tracking-[0.22em] text-[#C69C6D]">
          <Star className="h-3.5 w-3.5 fill-[#C69C6D]" />
          Your 22nd Year Time Capsule
        </div>
        <h3 className="mt-2 font-editorial text-2xl font-medium text-[#261C1A]">
          Write Down One Wish or Intention for 22
        </h3>
        <p className="mt-1.5 font-body text-xs text-[#6B5853]">
          Saved privately right here on your device so we can open it together when you turn 23.
        </p>

        <form onSubmit={handleSaveWish} className="mt-5 space-y-3">
          <textarea
            rows={3}
            value={wishText}
            onChange={(e) => setWishText(e.target.value)}
            placeholder="This year at 22, I hope to..."
            className="w-full rounded-xl border border-[#DFCBB8] bg-[#FAF6F0]/70 px-4 py-3 font-handwritten text-xl text-[#261C1A] placeholder:text-[#9A857E]/70 focus:border-[#8E3B46] focus:outline-none"
          />
          <button
            type="submit"
            className="inline-flex items-center gap-2 rounded-full border border-[#8E3B46]/30 bg-[#FAF6F0] px-5 py-2 font-body text-xs font-medium uppercase tracking-[0.14em] text-[#8E3B46] transition-colors hover:bg-[#8E3B46] hover:text-white"
          >
            <Sparkles className="h-3.5 w-3.5" />
            {savedWish ? "Update My Wish Note" : "Seal Wish in Time Capsule"}
          </button>
        </form>

        {savedWish && (
          <p className="mt-3 font-body text-xs text-[#8E3B46]">
            ✓ Saved safely in your keepsake capsule.
          </p>
        )}
      </motion.div>
    </section>
  );
}
