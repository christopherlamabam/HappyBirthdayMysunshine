import { useEffect, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import confetti from "canvas-confetti";
import { Eye, Heart, Shuffle, Sparkles } from "lucide-react";
import type { ReasonItem } from "../data/giftData";
import { soundEngine } from "../utils/soundEngine";

interface ReasonsDeckProps {
  heading: string;
  subheading: string;
  reasons: ReasonItem[];
  isMusicPlaying: boolean;
}

export function ReasonsDeck({
  heading,
  subheading,
  reasons,
  isMusicPlaying,
}: ReasonsDeckProps) {
  const [revealed, setRevealed] = useState<Record<number, boolean>>({ 1: true });
  const [spotlightReason, setSpotlightReason] = useState<ReasonItem | null>(null);
  const celebratedAllRef = useRef(false);

  const revealedCount = Object.values(revealed).filter(Boolean).length;
  const allRevealed = revealedCount >= reasons.length;

  useEffect(() => {
    if (allRevealed && !celebratedAllRef.current && reasons.length > 0) {
      celebratedAllRef.current = true;
      confetti({
        particleCount: 55,
        spread: 68,
        origin: { y: 0.7 },
        colors: ["#8E3B46", "#C69C6D", "#E8C89B", "#FAF6F0"],
      });
      if (isMusicPlaying) {
        soundEngine.playCelebrationArpeggio();
      }
    }
  }, [allRevealed, reasons.length, isMusicPlaying]);

  const toggleCard = (num: number) => {
    if (isMusicPlaying) {
      soundEngine.playCardChime();
    }
    setRevealed((prev) => ({ ...prev, [num]: !prev[num] }));
  };

  const handleDrawRandom = () => {
    const unrevealed = reasons.filter((r) => !revealed[r.number]);
    const pool = unrevealed.length > 0 ? unrevealed : reasons;
    const picked = pool[Math.floor(Math.random() * pool.length)];
    if (!picked) return;

    if (isMusicPlaying) {
      soundEngine.playCardChime();
    }
    setRevealed((prev) => ({ ...prev, [picked.number]: true }));
    setSpotlightReason(picked);
  };

  const handleRevealAll = () => {
    if (allRevealed) {
      celebratedAllRef.current = false;
      setRevealed({ 1: true });
      setSpotlightReason(null);
      return;
    }
    const next: Record<number, boolean> = {};
    reasons.forEach((r) => {
      next[r.number] = true;
    });
    setRevealed(next);
  };

  return (
    <section
      id="reasons"
      className="relative border-y border-[#E5D5C5]/70 bg-[#F4EAE1]/55 py-24 sm:py-32"
    >
      <div className="mx-auto max-w-6xl px-4 sm:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.75 }}
          className="mx-auto max-w-2xl text-center"
        >
          <span className="font-body text-xs font-medium uppercase tracking-[0.26em] text-[#8E3B46]">
            Chapter II · Twenty-Two Cards
          </span>
          <h2 className="mt-3 font-editorial text-4xl font-medium text-[#261C1A] sm:text-5xl">
            {heading}
          </h2>
          <p className="mt-4 font-body text-base text-[#6B5853]">{subheading}</p>

          {/* Progress & Actions */}
          <div className="mt-8 flex flex-col items-center gap-4">
            <div className="flex flex-wrap items-center justify-center gap-3">
              <button
                type="button"
                onClick={handleDrawRandom}
                className="inline-flex items-center gap-2 rounded-full bg-[#8E3B46] px-5 py-2.5 font-body text-xs font-medium uppercase tracking-[0.14em] text-white shadow-sm transition-all hover:bg-[#752D37]"
              >
                <Shuffle className="h-3.5 w-3.5" />
                Draw a Random Reason
              </button>

              <button
                type="button"
                onClick={handleRevealAll}
                className="inline-flex items-center gap-2 rounded-full border border-[#C69C6D]/60 bg-[#FFFDF9] px-5 py-2.5 font-body text-xs font-medium uppercase tracking-[0.14em] text-[#261C1A] transition-colors hover:border-[#8E3B46] hover:text-[#8E3B46]"
              >
                <Eye className="h-3.5 w-3.5" />
                {allRevealed ? "Fold Cards Back" : "Reveal All 22"}
              </button>
            </div>

            {/* Discovery Progress Pill */}
            <div className="flex items-center gap-3 rounded-full border border-[#E2D2C2] bg-[#FFFDF9] px-4 py-1.5 text-xs text-[#6B5853]">
              <Heart className="h-3.5 w-3.5 fill-[#8E3B46] text-[#8E3B46]" />
              <span>
                <strong className="font-semibold text-[#261C1A]">
                  {revealedCount}
                </strong>{" "}
                of {reasons.length} discovered
              </span>
              <div className="h-1.5 w-24 overflow-hidden rounded-full bg-[#EFE2D7]">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-[#C69C6D] to-[#8E3B46] transition-all duration-500"
                  style={{
                    width: `${Math.round((revealedCount / reasons.length) * 100)}%`,
                  }}
                />
              </div>
            </div>
          </div>
        </motion.div>

        {/* Spotlight Drawn Card Banner */}
        <AnimatePresence mode="wait">
          {spotlightReason && (
            <motion.div
              key={spotlightReason.number}
              initial={{ opacity: 0, y: -12, scale: 0.97 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -8, scale: 0.97 }}
              transition={{ duration: 0.4 }}
              className="mx-auto mt-10 max-w-xl rounded-2xl border border-[#C69C6D]/50 bg-[#FFFDF9] p-6 text-center shadow-[0_18px_40px_-18px_rgba(142,59,70,0.22)]"
            >
              <div className="inline-flex items-center gap-1.5 text-[11px] font-medium uppercase tracking-[0.2em] text-[#C69C6D]">
                <Sparkles className="h-3.5 w-3.5" />
                Reason #{String(spotlightReason.number).padStart(2, "0")} ·{" "}
                {spotlightReason.tag}
              </div>
              <h3 className="mt-2 font-editorial text-2xl font-semibold text-[#261C1A]">
                {spotlightReason.title}
              </h3>
              <p className="mt-2 font-body text-sm leading-relaxed text-[#6B5853]">
                {spotlightReason.note}
              </p>
            </motion.div>
          )}
        </AnimatePresence>

        {/* 22 Keepsake Cards Grid */}
        <div className="mt-12 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4 lg:gap-5">
          {reasons.map((reason, idx) => {
            const isFlipped = Boolean(revealed[reason.number]);
            const formattedNum = String(reason.number).padStart(2, "0");

            return (
              <motion.div
                key={reason.number}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.15 }}
                transition={{ duration: 0.5, delay: (idx % 4) * 0.05 }}
                className="perspective-1200"
              >
                <div
                  onClick={() => toggleCard(reason.number)}
                  role="button"
                  tabIndex={0}
                  onKeyDown={(e) => {
                    if (e.key === "Enter" || e.key === " ") {
                      e.preventDefault();
                      toggleCard(reason.number);
                    }
                  }}
                  aria-label={`Reason ${reason.number}: ${
                    isFlipped ? reason.title : "Tap to reveal"
                  }`}
                  className="group relative h-52 w-full cursor-pointer select-none preserve-3d transition-transform duration-700 sm:h-56"
                  style={{
                    transform: isFlipped ? "rotateY(180deg)" : "rotateY(0deg)",
                  }}
                >
                  {/* FRONT: Sealed Keepsake Card */}
                  <div className="absolute inset-0 flex flex-col items-center justify-between overflow-hidden rounded-xl border border-[#DFCBB8] bg-gradient-to-br from-[#FFFDF9] to-[#F7ECE1] p-4 shadow-sm transition-shadow duration-300 group-hover:border-[#C69C6D] group-hover:shadow-md backface-hidden">
                    {/* Decorative Inner Frame */}
                    <div className="pointer-events-none absolute inset-2 rounded-lg border border-[#C69C6D]/25" />

                    <span className="font-body text-[10px] font-medium uppercase tracking-[0.22em] text-[#9A857E]">
                      {reason.tag}
                    </span>

                    <div className="text-center">
                      <span className="font-editorial text-4xl font-semibold italic text-[#8E3B46] sm:text-5xl">
                        {formattedNum}
                      </span>
                    </div>

                    <span className="font-handwritten text-base text-[#C69C6D]">
                      Tap to turn over
                    </span>
                  </div>

                  {/* BACK: Revealed Reason */}
                  <div className="absolute inset-0 flex flex-col justify-between overflow-hidden rounded-xl border border-[#8E3B46]/25 bg-[#FFFDF9] p-4 shadow-md backface-hidden rotate-y-180">
                    <div className="flex items-center justify-between border-b border-[#F2E7DC] pb-1.5">
                      <span className="font-editorial text-sm font-semibold italic text-[#8E3B46]">
                        #{formattedNum}
                      </span>
                      <span className="font-body text-[9px] font-medium uppercase tracking-[0.18em] text-[#C69C6D]">
                        {reason.tag}
                      </span>
                    </div>

                    <div className="my-auto py-1">
                      <h3 className="font-editorial text-lg font-semibold leading-snug text-[#261C1A] sm:text-xl">
                        {reason.title}
                      </h3>
                      <p className="mt-1.5 font-body text-xs leading-relaxed text-[#6B5853] line-clamp-4">
                        {reason.note}
                      </p>
                    </div>

                    <div className="flex items-center justify-end">
                      <Heart className="h-3 w-3 fill-[#8E3B46]/20 text-[#8E3B46]/60" />
                    </div>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
