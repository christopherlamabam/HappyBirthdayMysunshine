import { useEffect, useRef } from "react";

interface Particle {
  x: number;
  y: number;
  radius: number;
  vx: number;
  vy: number;
  alpha: number;
  rotation: number;
  vRotation: number;
  isPetal: boolean;
  color: string;
}

export function FloatingPetalsCanvas() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let animationFrameId = 0;
    let width = window.innerWidth;
    let height = window.innerHeight;

    const handleResize = () => {
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      width = window.innerWidth;
      height = window.innerHeight;
      canvas.width = width * dpr;
      canvas.height = height * dpr;
      canvas.style.width = `${width}px`;
      canvas.style.height = `${height}px`;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };

    handleResize();
    window.addEventListener("resize", handleResize);

    const palette = [
      "rgba(198, 156, 109, 0.35)", // Burnished gold
      "rgba(200, 125, 117, 0.25)", // Soft terracotta rose
      "rgba(142, 59, 70, 0.16)",   // Subtle rose wine
      "rgba(232, 200, 155, 0.35)", // Warm champagne
    ];

    const count = Math.min(34, Math.max(18, Math.floor(width / 45)));
    const particles: Particle[] = Array.from({ length: count }, (_, i) => ({
      x: Math.random() * width,
      y: Math.random() * height,
      radius: i % 3 === 0 ? 4 + Math.random() * 4 : 1.5 + Math.random() * 2.5,
      vx: (Math.random() - 0.3) * 0.35,
      vy: 0.18 + Math.random() * 0.38,
      alpha: 0.25 + Math.random() * 0.45,
      rotation: Math.random() * Math.PI * 2,
      vRotation: (Math.random() - 0.5) * 0.012,
      isPetal: i % 3 === 0,
      color: palette[i % palette.length],
    }));

    let t = 0;

    const render = () => {
      t += 0.01;
      ctx.clearRect(0, 0, width, height);

      for (const p of particles) {
        p.x += p.vx + Math.sin(t + p.y * 0.01) * 0.22;
        p.y += p.vy;
        p.rotation += p.vRotation;

        if (p.y > height + 20) {
          p.y = -20;
          p.x = Math.random() * width;
        }
        if (p.x > width + 20) p.x = -20;
        if (p.x < -20) p.x = width + 20;

        ctx.save();
        ctx.translate(p.x, p.y);
        ctx.rotate(p.rotation);
        ctx.globalAlpha = p.alpha;
        ctx.fillStyle = p.color;

        if (p.isPetal) {
          ctx.beginPath();
          ctx.ellipse(0, 0, p.radius * 1.4, p.radius * 0.72, 0, 0, Math.PI * 2);
          ctx.fill();
        } else {
          ctx.beginPath();
          ctx.arc(0, 0, p.radius, 0, Math.PI * 2);
          ctx.fill();
        }

        ctx.restore();
      }

      animationFrameId = window.requestAnimationFrame(render);
    };

    animationFrameId = window.requestAnimationFrame(render);

    return () => {
      window.cancelAnimationFrame(animationFrameId);
      window.removeEventListener("resize", handleResize);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      aria-hidden="true"
      className="pointer-events-none fixed inset-0 z-10 opacity-85"
    />
  );
}
