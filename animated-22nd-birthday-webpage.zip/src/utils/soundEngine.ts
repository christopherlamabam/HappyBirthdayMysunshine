class GentleSoundEngine {
  private ctx: AudioContext | null = null;
  private isPlaying = false;
  private loopTimer: number | null = null;
  private stepIndex = 0;

  // Dreamy music-box melody frequencies (C5, E5, G5, B5, A5, E5, F5, C6...)
  private readonly melodyNotes = [
    523.25, // C5
    659.25, // E5
    783.99, // G5
    987.77, // B5
    880.0,  // A5
    659.25, // E5
    698.46, // F5
    880.0,  // A5
    783.99, // G5
    659.25, // E5
    587.33, // D5
    698.46, // F5
    659.25, // E5
    523.25, // C5
    392.0,  // G4
    523.25, // C5
  ];

  private ensureContext(): AudioContext | null {
    if (typeof window === "undefined") return null;
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === "suspended") {
      this.ctx.resume().catch(() => {});
    }
    return this.ctx;
  }

  private playTone(freq: number, duration = 1.6, volume = 0.035, type: OscillatorType = "sine") {
    const ctx = this.ensureContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const harmonic = ctx.createOscillator();
    const gain = ctx.createGain();
    const harmonicGain = ctx.createGain();

    osc.type = type;
    osc.frequency.setValueAtTime(freq, now);

    // Subtle music-box octave sparkle
    harmonic.type = "triangle";
    harmonic.frequency.setValueAtTime(freq * 2, now);

    gain.gain.setValueAtTime(0.0001, now);
    gain.gain.exponentialRampToValueAtTime(volume, now + 0.03);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + duration);

    harmonicGain.gain.setValueAtTime(0.0001, now);
    harmonicGain.gain.exponentialRampToValueAtTime(volume * 0.25, now + 0.02);
    harmonicGain.gain.exponentialRampToValueAtTime(0.0001, now + duration * 0.55);

    osc.connect(gain);
    harmonic.connect(harmonicGain);
    gain.connect(ctx.destination);
    harmonicGain.connect(ctx.destination);

    osc.start(now);
    harmonic.start(now);
    osc.stop(now + duration + 0.05);
    harmonic.stop(now + duration + 0.05);
  }

  public startMusicBox() {
    if (this.isPlaying) return;
    this.ensureContext();
    this.isPlaying = true;
    this.stepIndex = 0;

    const tick = () => {
      if (!this.isPlaying) return;
      const freq = this.melodyNotes[this.stepIndex % this.melodyNotes.length];
      this.playTone(freq, 2.2, 0.032, "sine");
      this.stepIndex += 1;
      this.loopTimer = window.setTimeout(tick, 680);
    };

    tick();
  }

  public stopMusicBox() {
    this.isPlaying = false;
    if (this.loopTimer !== null) {
      window.clearTimeout(this.loopTimer);
      this.loopTimer = null;
    }
  }

  public toggleMusicBox(): boolean {
    if (this.isPlaying) {
      this.stopMusicBox();
      return false;
    } else {
      this.startMusicBox();
      return true;
    }
  }

  public getIsPlaying(): boolean {
    return this.isPlaying;
  }

  public playSealChime() {
    const chord = [523.25, 659.25, 783.99, 1046.5];
    chord.forEach((freq, idx) => {
      window.setTimeout(() => {
        this.playTone(freq, 1.9, 0.04, "sine");
      }, idx * 95);
    });
  }

  public playCardChime() {
    this.playTone(783.99, 0.85, 0.024, "sine");
  }

  public playCelebrationArpeggio() {
    const notes = [523.25, 659.25, 783.99, 987.77, 1046.5, 1318.51];
    notes.forEach((freq, idx) => {
      window.setTimeout(() => {
        this.playTone(freq, 2.0, 0.04, "sine");
      }, idx * 80);
    });
  }
}

export const soundEngine = new GentleSoundEngine();
