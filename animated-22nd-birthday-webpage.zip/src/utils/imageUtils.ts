export interface OptimizedPhoto {
  dataUrl: string;
  width: number;
  height: number;
  bytes: number;
  originalBytes: number;
  name: string;
}

const ACCEPTED_EXTENSIONS = /\.(jpe?g|png|webp|gif|avif|bmp|heic|heif)$/i;
const MAX_INPUT_BYTES = 30 * 1024 * 1024; // 30 MB source limit
const MAX_OUTPUT_BYTES = 340 * 1024; // aim for ~340 KB per optimized photo
const MAX_DIMENSION = 1400;

export function isProbablyImageFile(file: File): boolean {
  return file.type.startsWith("image/") || ACCEPTED_EXTENSIONS.test(file.name);
}

export function formatBytes(bytes: number): string {
  if (!Number.isFinite(bytes) || bytes <= 0) return "0 KB";
  if (bytes < 1024 * 1024) return `${Math.max(1, Math.round(bytes / 1024))} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

/** Approximate decoded byte size of a data URL string. */
export function dataUrlByteSize(value: string): number {
  if (!value || !value.startsWith("data:")) return 0;
  const comma = value.indexOf(",");
  if (comma === -1) return 0;
  const base64 = value.slice(comma + 1);
  return Math.round((base64.length * 3) / 4);
}

function readAsDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result || ""));
    reader.onerror = () => reject(new Error(`Could not read ${file.name}.`));
    reader.readAsDataURL(file);
  });
}

function loadImageElement(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () =>
      reject(
        new Error(
          "That picture format cannot be read by this browser. iPhone HEIC photos should be exported as JPG first (Settings → Camera → Formats → Most Compatible), or choose another photo."
        )
      );
    img.src = src;
  });
}

async function decodePhoto(file: File): Promise<{
  width: number;
  height: number;
  draw: (ctx: CanvasRenderingContext2D, w: number, h: number) => void;
}> {
  // Modern browsers can decode + respect EXIF orientation in one step.
  if (typeof createImageBitmap === "function") {
    try {
      const bitmap = await createImageBitmap(file, {
        imageOrientation: "from-image",
      });
      return {
        width: bitmap.width,
        height: bitmap.height,
        draw: (ctx, w, h) => ctx.drawImage(bitmap, 0, 0, w, h),
      };
    } catch {
      // Fall through to the <img> fallback below.
    }
  }

  const objectUrl = URL.createObjectURL(file);
  try {
    const img = await loadImageElement(objectUrl);
    return {
      width: img.naturalWidth || img.width,
      height: img.naturalHeight || img.height,
      draw: (ctx, w, h) => ctx.drawImage(img, 0, 0, w, h),
    };
  } finally {
    URL.revokeObjectURL(objectUrl);
  }
}

/**
 * Resizes and compresses a photo entirely in the browser so it can be stored
 * locally and embedded into an exported keepsake page.
 */
export async function optimizePhoto(file: File): Promise<OptimizedPhoto> {
  if (!isProbablyImageFile(file)) {
    throw new Error(`“${file.name}” is not a photo file. Choose a JPG, PNG, WEBP, GIF or AVIF image.`);
  }
  if (file.size > MAX_INPUT_BYTES) {
    throw new Error(`“${file.name}” is ${formatBytes(file.size)} — please use a photo smaller than 30 MB.`);
  }

  const source = await decodePhoto(file);
  if (!source.width || !source.height) {
    throw new Error(`We could not measure “${file.name}”. Try a JPG or PNG copy instead.`);
  }

  const canvas = document.createElement("canvas");
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("Your browser blocked image processing. Try a different browser.");

  let scale = Math.min(1, MAX_DIMENSION / Math.max(source.width, source.height));
  let dataUrl = "";
  let width = 0;
  let height = 0;

  // Progressively reduce size/quality until the photo is lightweight.
  for (let attempt = 0; attempt < 5; attempt++) {
    width = Math.max(1, Math.round(source.width * scale));
    height = Math.max(1, Math.round(source.height * scale));
    canvas.width = width;
    canvas.height = height;

    // Fill first so transparent PNGs don't render as black in JPEG output.
    ctx.fillStyle = "#FFFDF9";
    ctx.fillRect(0, 0, width, height);
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = "high";
    source.draw(ctx, width, height);

    const quality = Math.max(0.56, 0.86 - attempt * 0.08);
    dataUrl = canvas.toDataURL("image/jpeg", quality);
    if (dataUrlByteSize(dataUrl) <= MAX_OUTPUT_BYTES) break;
    scale *= 0.82;
  }

  canvas.width = 0;
  canvas.height = 0;

  if (!dataUrl.startsWith("data:image/")) {
    throw new Error("We couldn't optimize that photo. Try a JPG or PNG file.");
  }

  return {
    dataUrl,
    width,
    height,
    bytes: dataUrlByteSize(dataUrl),
    originalBytes: file.size,
    name: file.name,
  };
}

export async function optimizePhotos(files: File[]): Promise<{
  photos: OptimizedPhoto[];
  errors: string[];
}> {
  const photos: OptimizedPhoto[] = [];
  const errors: string[] = [];

  for (const file of files) {
    try {
      photos.push(await optimizePhoto(file));
    } catch (error) {
      errors.push(error instanceof Error ? error.message : `Could not add ${file.name}.`);
    }
  }

  return { photos, errors };
}

export { readAsDataUrl };
