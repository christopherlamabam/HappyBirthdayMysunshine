import { useEffect, useState } from "react";
import { AnimatePresence, MotionConfig } from "framer-motion";
import { Feather, Heart } from "lucide-react";
import {
  loadGiftData,
  resetGiftData,
  saveGiftData,
  type BirthdayGiftData,
  type SaveResult,
} from "./data/giftData";
import { soundEngine } from "./utils/soundEngine";
import { FloatingPetalsCanvas } from "./components/FloatingPetalsCanvas";
import { EnvelopeIntro } from "./components/EnvelopeIntro";
import { NavigationBar } from "./components/NavigationBar";
import { HeroChapter } from "./components/HeroChapter";
import { MemoriesGallery } from "./components/MemoriesGallery";
import { ReasonsDeck } from "./components/ReasonsDeck";
import { LoveLetterSection } from "./components/LoveLetterSection";
import { CandleWishStage } from "./components/CandleWishStage";
import { BirthdayGiftPass } from "./components/BirthdayGiftPass";
import { CustomizeStudioModal } from "./components/CustomizeStudioModal";

export default function App() {
  const [giftData, setGiftData] = useState<BirthdayGiftData>(() =>
    loadGiftData()
  );
  const [envelopeOpen, setEnvelopeOpen] = useState(false);
  const [isMusicPlaying, setIsMusicPlaying] = useState(false);
  const [studioOpen, setStudioOpen] = useState(false);

  // Sync dynamic document title & check optional ?customize=1 query param
  useEffect(() => {
    document.title = `Happy 22nd Birthday, ${giftData.recipientName} — A Keepsake Letter`;
  }, [giftData.recipientName]);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.get("customize") === "1" || params.get("edit") === "1") {
      setEnvelopeOpen(true);
      setStudioOpen(true);
    }

    const handleHashChange = () => {
      setGiftData(loadGiftData());
    };
    window.addEventListener("hashchange", handleHashChange);

    return () => {
      window.removeEventListener("hashchange", handleHashChange);
      soundEngine.stopMusicBox();
    };
  }, []);

  const handleOpenEnvelopeComplete = (withMusic: boolean) => {
    setEnvelopeOpen(true);
    if (withMusic) {
      soundEngine.startMusicBox();
      setIsMusicPlaying(true);
    }
  };

  const handleToggleMusic = () => {
    const nextState = soundEngine.toggleMusicBox();
    setIsMusicPlaying(nextState);
  };

  const handleReplayEnvelope = () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
    setEnvelopeOpen(false);
  };

  const handleSaveCustomData = (nextData: BirthdayGiftData): SaveResult => {
    setGiftData(nextData);
    return saveGiftData(nextData);
  };

  const handleResetCustomData = () => {
    const defaults = resetGiftData();
    setGiftData(defaults);
  };

  return (
    <MotionConfig reducedMotion="user">
      <div className="relative min-h-screen bg-[#FAF6F0] text-[#261C1A] paper-grain">
        {/* Ambient Drifting Petals & Golden Motes */}
        <FloatingPetalsCanvas />

        {/* Act 0: Wax-Sealed Envelope Curtain */}
        <AnimatePresence>
          {!envelopeOpen && (
            <EnvelopeIntro
              recipientName={giftData.recipientName}
              senderName={giftData.senderName}
              envelopeNote={giftData.envelopeNote}
              displayDate={giftData.birthdayDisplayDate}
              onOpenComplete={handleOpenEnvelopeComplete}
            />
          )}
        </AnimatePresence>

        {/* Main Keepsake Webpage (Mounted smoothly after or ready underneath) */}
        {envelopeOpen && (
          <>
            <NavigationBar
              recipientName={giftData.recipientName}
              isMusicPlaying={isMusicPlaying}
              onToggleMusic={handleToggleMusic}
              onReplayEnvelope={handleReplayEnvelope}
              onOpenStudio={() => setStudioOpen(true)}
            />

            <main className="relative z-20">
              {/* Act I: Kinetic Editorial Hero */}
              <HeroChapter
                recipientName={giftData.recipientName}
                recipientNickname={giftData.recipientNickname}
                senderName={giftData.senderName}
                birthDate={giftData.birthDate}
                eyebrow={giftData.heroEyebrow}
                headline={giftData.heroHeadline}
                subtitle={giftData.heroSubtitle}
                previewMemories={giftData.memories}
              />

              {/* Act II: Interactive 3D Polaroid Memories */}
              <MemoriesGallery
                heading={giftData.memoriesHeading}
                subheading={giftData.memoriesSubheading}
                memories={giftData.memories}
                isMusicPlaying={isMusicPlaying}
              />

              {/* Act III: 22 Reasons Keepsake Card Deck */}
              <ReasonsDeck
                heading={giftData.reasonsHeading}
                subheading={giftData.reasonsSubheading}
                reasons={giftData.reasons}
                isMusicPlaying={isMusicPlaying}
              />

              {/* Act IV: Handwritten Cotton-Paper Love Letter */}
              <LoveLetterSection
                heading={giftData.letterHeading}
                letterDate={giftData.letterDate}
                greeting={giftData.letterGreeting}
                paragraphs={giftData.letterParagraphs}
                closing={giftData.letterClosing}
                senderName={giftData.senderName}
              />

              {/* Act V: Velvet Midnight 22-Candle Wish Stage */}
              <CandleWishStage
                recipientName={giftData.recipientName}
                headline={giftData.wishStageHeadline}
                subheading={giftData.wishStageSubheading}
                isMusicPlaying={isMusicPlaying}
              />

              {/* Act VI: Luxury Gift Voucher & Year 22 Time Capsule */}
              <BirthdayGiftPass
                recipientName={giftData.recipientName}
                senderName={giftData.senderName}
                coupon={giftData.coupon}
                isMusicPlaying={isMusicPlaying}
              />
            </main>

            {/* Discreet Keepsake Footer */}
            <footer className="relative z-20 border-t border-[#E5D5C5] bg-[#F5ECE2]/70 px-4 py-12 text-center">
              <div className="mx-auto max-w-2xl space-y-3">
                <div className="inline-flex items-center gap-2 font-editorial text-xl italic text-[#8E3B46]">
                  <Heart className="h-4 w-4 fill-[#8E3B46]" />
                  <span>
                    Made with love for {giftData.recipientName}’s 22nd Birthday
                  </span>
                </div>
                <p className="font-body text-xs text-[#6B5853]">
                  {giftData.birthdayDisplayDate} · Dedicated by {giftData.senderName}
                </p>

                <div className="pt-4">
                  <button
                    type="button"
                    onClick={() => setStudioOpen(true)}
                    className="inline-flex items-center gap-1.5 rounded-full border border-[#DFCBB8] bg-[#FFFDF9] px-4 py-1.5 font-body text-[11px] font-medium text-[#6B5853] transition-colors hover:border-[#8E3B46]/40 hover:text-[#8E3B46]"
                  >
                    <Feather className="h-3 w-3" />
                    Upload Photos &amp; Edit Your Details
                  </button>
                </div>
              </div>
            </footer>
          </>
        )}

        {/* Discreet Live Personalization Studio Modal */}
        <CustomizeStudioModal
          isOpen={studioOpen}
          data={giftData}
          onClose={() => setStudioOpen(false)}
          onSave={handleSaveCustomData}
          onReset={handleResetCustomData}
        />
      </div>
    </MotionConfig>
  );
}
