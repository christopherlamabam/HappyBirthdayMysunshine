export interface MemoryItem {
  id: string;
  imageUrl: string;
  dateLabel: string;
  location: string;
  caption: string;
  backStory: string;
}

export interface ReasonItem {
  number: number;
  title: string;
  note: string;
  tag: string;
}

export interface GiftCoupon {
  eyebrow: string;
  title: string;
  subtitle: string;
  dateText: string;
  locationText: string;
  secretPromise: string;
}

export interface BirthdayGiftData {
  recipientName: string;
  recipientNickname: string;
  senderName: string;
  birthDate: string; // YYYY-MM-DD (used to compute live days/hours/seconds alive)
  birthdayDisplayDate: string;
  envelopeNote: string;
  heroEyebrow: string;
  heroHeadline: string;
  heroSubtitle: string;
  memoriesHeading: string;
  memoriesSubheading: string;
  memories: MemoryItem[];
  reasonsHeading: string;
  reasonsSubheading: string;
  reasons: ReasonItem[];
  letterHeading: string;
  letterDate: string;
  letterGreeting: string;
  letterParagraphs: string[];
  letterClosing: string;
  wishStageHeadline: string;
  wishStageSubheading: string;
  coupon: GiftCoupon;
}

export const DEFAULT_GIFT_DATA: BirthdayGiftData = {
  recipientName: "Clara",
  recipientNickname: "my favorite person",
  senderName: "Julian",
  birthDate: "2004-05-14",
  birthdayDisplayDate: "Chapter XXII · May 14",
  envelopeNote: "For Clara, on the morning you turn twenty-two",
  heroEyebrow: "A Keepsake Edition · Written With All My Love",
  heroHeadline: "Twenty-Two Looks Like Sunlight on You",
  heroSubtitle:
    "Every laugh, every late-night walk, and every quiet coffee morning brought you here—and I feel endlessly lucky to witness your twenty-second chapter up close.",
  memoriesHeading: "Pages From Our Favorite Days",
  memoriesSubheading:
    "Tap any Polaroid to flip it over and read the note tucked on the back.",
  memories: [
    {
      id: "mem-1",
      imageUrl:
        "https://images.pexels.com/photos/16399253/pexels-photo-16399253.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
      dateLabel: "Golden Hour · Chapter 01",
      location: "Meadow Trail",
      caption: "The laugh that made the whole afternoon slow down.",
      backStory:
        "I still remember thinking nobody should be allowed to look that radiant just standing in tall grass before sunset. I took three blurry photos before this one because I couldn't stop smiling.",
    },
    {
      id: "mem-2",
      imageUrl:
        "https://images.pexels.com/photos/5530720/pexels-photo-5530720.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
      dateLabel: "Sunday Morning · Chapter 02",
      location: "Our Corner Park",
      caption: "Half-read pages, iced coffee, and nowhere else to be.",
      backStory:
        "This was the exact weekend I realized doing absolutely nothing with you beats every big plan I could ever put on a calendar.",
    },
    {
      id: "mem-3",
      imageUrl:
        "https://images.pexels.com/photos/5383861/pexels-photo-5383861.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
      dateLabel: "Spontaneous Drive · Chapter 03",
      location: "Coastline Overlook",
      caption: "Wind in your hair, salt air, and your playlist on repeat.",
      backStory:
        "We packed snacks in five minutes, missed the turn twice, and somehow ended up watching the nicest sunset of the entire year together.",
    },
    {
      id: "mem-4",
      imageUrl:
        "https://images.pexels.com/photos/31925683/pexels-photo-31925683.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
      dateLabel: "Dusk Bonfire · Chapter 04",
      location: "By the Water",
      caption: "Warm embers, burnt marshmallows, and whispering until midnight.",
      backStory:
        "You insisted yours wasn't burnt, offered me the slightly charred half anyway, and kept my cold hands inside your sleeves on the walk back.",
    },
    {
      id: "mem-5",
      imageUrl:
        "https://images.pexels.com/photos/13870508/pexels-photo-13870508.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
      dateLabel: "Quiet Promise · Chapter 05",
      location: "Under the Trees",
      caption: "My favorite place in the world is right beside you.",
      backStory:
        "Whenever life feels loud or rushed, one minute talking to you brings everything back to earth. Thank you for being my calmest home.",
    },
    {
      id: "mem-6",
      imageUrl:
        "https://images.pexels.com/photos/30308905/pexels-photo-30308905.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
      dateLabel: "Today · Chapter 22",
      location: "Right Here With You",
      caption: "Sparklers lit for everything your 22nd year will bring.",
      backStory:
        "Happy 22nd birthday, gorgeous. Whatever dreams you whisper tonight, I want to help every single one of them come true.",
    },
  ],
  reasonsHeading: "22 Reasons You Mean Everything to Me",
  reasonsSubheading:
    "Twenty-two small truths for twenty-two luminous years. Turn over each keepsake card—or draw one at random.",
  reasons: [
    {
      number: 1,
      title: "Your Morning Voice",
      note: "Even half-asleep, the very first 'good morning' you mumble makes my entire day feel lighter.",
      tag: "Little Things",
    },
    {
      number: 2,
      title: "The Way You Notice People",
      note: "You remember everyone's coffee order, check in when friends go quiet, and make rooms kinder just by arriving.",
      tag: "Your Heart",
    },
    {
      number: 3,
      title: "Your Genuine Laugh",
      note: "Not the polite laugh—the real, eyes-crinkling, shoulder-shaking laugh you let out when something catches you off guard.",
      tag: "Joy",
    },
    {
      number: 4,
      title: "Your Curious Mind",
      note: "How you fall down late-night rabbit holes and wake up eager to teach me three new facts over breakfast.",
      tag: "Mind",
    },
    {
      number: 5,
      title: "How You Hold My Hand",
      note: "That quiet little squeeze you give twice without saying a word when we're walking side by side.",
      tag: "Closeness",
    },
    {
      number: 6,
      title: "Your Fierce Loyalty",
      note: "When you love someone, you stand in their corner completely—and I never take being on your team for granted.",
      tag: "Devotion",
    },
    {
      number: 7,
      title: "Your Car Karaoke",
      note: "Watching you turn every red light into a headline concert makes traffic my favorite part of the week.",
      tag: "Adventures",
    },
    {
      number: 8,
      title: "Your Resilience",
      note: "Even on tough weeks, you dust yourself off with so much grace, courage, and quiet strength.",
      tag: "Strength",
    },
    {
      number: 9,
      title: "The Way You Look at Food",
      note: "The pure, unbothered happiness on your face when your favorite pastry arrives at the table.",
      tag: "Sweetness",
    },
    {
      number: 10,
      title: "Your Warmth With Strangers",
      note: "You compliment people effortlessly and leave baristas, neighbors, and puppies smiling after you pass.",
      tag: "Kindness",
    },
    {
      number: 11,
      title: "Our Inside Jokes",
      note: "How one glance across a crowded dinner table can set both of us laughing without a single syllable spoken.",
      tag: "Us",
    },
    {
      number: 12,
      title: "Your Honest Heart",
      note: "I never have to guess where we stand; you speak with tenderness, clarity, and rare emotional courage.",
      tag: "Trust",
    },
    {
      number: 13,
      title: "How Cozy You Make Home Feel",
      note: "A candle, a soft blanket, your favorite playlist—suddenly any ordinary Tuesday feels like a sanctuary.",
      tag: "Home",
    },
    {
      number: 14,
      title: "Your Creative Spark",
      note: "You notice colors, light, tiny details, and stories everyone else walks straight past.",
      tag: "Beauty",
    },
    {
      number: 15,
      title: "Your Patience With Me",
      note: "When I overthink or miss the obvious, you meet me with gentleness instead of judgment.",
      tag: "Grace",
    },
    {
      number: 16,
      title: "Your Golden-Hour Glow",
      note: "Honestly, sunset photography was invented just to try and keep up with how you look at 6:30 PM.",
      tag: "Radiance",
    },
    {
      number: 17,
      title: "How You Dream Big",
      note: "Watching you chase the future you want inspires me to work harder and dream braver right alongside you.",
      tag: "Future",
    },
    {
      number: 18,
      title: "Your Comforting Hugs",
      note: "Ten seconds in your arms resets my nervous system better than eight hours of sleep ever could.",
      tag: "Peace",
    },
    {
      number: 19,
      title: "Your Playful Teasing",
      note: "You keep me grounded, never let me take myself too seriously, and always keep things sparkling.",
      tag: "Spark",
    },
    {
      number: 20,
      title: "Your Thoughtful Gifts & Notes",
      note: "You listen carefully to small offhand wishes and remember them months later when nobody expects it.",
      tag: "Thoughtful",
    },
    {
      number: 21,
      title: "How Safe It Feels to Be Myself",
      note: "With you, I never have to wear armor or pretend—I get to just breathe and be completely me.",
      tag: "Safe Harbor",
    },
    {
      number: 22,
      title: "Every Tomorrow Ahead of Us",
      note: "As grateful as I am for every memory behind us, my favorite part of loving you is everything we haven't lived yet.",
      tag: "Chapter 22",
    },
  ],
  letterHeading: "A Letter For Year Twenty-Two",
  letterDate: "Written on the Eve of Your 22nd Birthday",
  letterGreeting: "Dearest Clara,",
  letterParagraphs: [
    "Happy twenty-second birthday, my love. I wanted to build you something quieter and more lasting than a quick text or a store-bought card—a small corner of the world that belongs entirely to you today.",
    "Turning twenty-two has this rare, electric magic to it. You are stepping deeper into who you are—wiser than you were at twenty, softer where it counts, braver in what you refuse to settle for, and somehow even brighter than the day I first met you.",
    "Watching you grow, laugh, care fiercely for the people in your life, and turn ordinary errands into memories I treasure is the privilege of my life. Thank you for every late-night talk, every shared bite of dessert, and every ounce of warmth you pour into us.",
    "My wish for your twenty-second year is simple: may it bring you slow mornings, adventures that take your breath away, friendships that keep you rooted, and peace so deep you feel it in your bones. And wherever this year carries you, know that I am cheering loudest from right beside you.",
  ],
  letterClosing: "Forever yours, today & every birthday after,",
  wishStageHeadline: "Close Your Eyes & Make Your 22nd Wish",
  wishStageSubheading:
    "Twenty-two candles lit just for you. Tap individual flames or hold your breath and blow them all out together.",
  coupon: {
    eyebrow: "Admit One · Birthday Keepsake Voucher",
    title: "A Candlelit Dinner & Sunset Escape",
    subtitle:
      "Redeemable for your favorite rooftop dinner, warm sourdough, gelato afterwards, and a full weekend adventure planned entirely around you.",
    dateText: "Whenever Your Heart Chooses",
    locationText: "Your Favorite Table · Dressed Up Together",
    secretPromise:
      "Plus unlimited forehead kisses, zero alarm clocks, and your playlist on the drive home.",
  },
};

const STORAGE_KEY = "birthday_keepsake_gift_v1";

export interface SaveResult {
  ok: boolean;
  message?: string;
}

interface InjectedGiftWindow extends Window {
  __GIFT_DATA__?: BirthdayGiftData;
}

export function hasInjectedGiftData(): boolean {
  if (typeof window === "undefined") return false;
  const injected = (window as InjectedGiftWindow).__GIFT_DATA__;
  return Boolean(injected && typeof injected === "object");
}

function encodeBase64Utf8(str: string): string {
  const bytes = new TextEncoder().encode(str);
  let binary = "";
  bytes.forEach((b) => {
    binary += String.fromCharCode(b);
  });
  return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

function decodeBase64Utf8(encoded: string): string {
  const normalized = encoded.replace(/-/g, "+").replace(/_/g, "/");
  const pad = normalized.length % 4 === 0 ? "" : "=".repeat(4 - (normalized.length % 4));
  const binary = atob(normalized + pad);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  return new TextDecoder().decode(bytes);
}

function mergeGiftData(parsed: Partial<BirthdayGiftData>): BirthdayGiftData {
  return {
    ...DEFAULT_GIFT_DATA,
    ...parsed,
    coupon: { ...DEFAULT_GIFT_DATA.coupon, ...(parsed.coupon || {}) },
  };
}

export function loadGiftData(): BirthdayGiftData {
  if (typeof window === "undefined") return DEFAULT_GIFT_DATA;

  // 0. A downloaded keepsake page carries its content (and photos) inline.
  //    This wins over browser storage so the gift travels with the file.
  const injected = (window as InjectedGiftWindow).__GIFT_DATA__;
  if (injected && typeof injected === "object") {
    return mergeGiftData(injected);
  }

  // 1. Check URL hash (#gift=...) first so shared personalized links work instantly
  try {
    const hash = window.location.hash;
    if (hash.startsWith("#gift=")) {
      const payload = hash.slice(6);
      const parsed = JSON.parse(decodeBase64Utf8(payload));
      return mergeGiftData(parsed);
    }
  } catch {
    // Fallback cleanly if malformed hash
  }

  // 2. Check localStorage
  try {
    const saved = window.localStorage.getItem(STORAGE_KEY);
    if (saved) {
      const parsed = JSON.parse(saved);
      return mergeGiftData(parsed);
    }
  } catch {
    // Ignore storage errors
  }

  return DEFAULT_GIFT_DATA;
}

export function saveGiftData(data: BirthdayGiftData): SaveResult {
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    return { ok: true };
  } catch (error) {
    const isQuota =
      error instanceof DOMException &&
      (error.name === "QuotaExceededError" ||
        error.name === "NS_ERROR_DOM_QUOTA_REACHED");

    return {
      ok: false,
      message: isQuota
        ? "Your browser's 5 MB storage is full. Try fewer photos (or smaller JPGs), remove a Polaroid, or use “Download Complete Gift Page” so the photos live inside the file instead."
        : "Your browser blocked local saving (private mode?). You can still use “Download Complete Gift Page” to keep your photos.",
    };
  }
}

export function resetGiftData(): BirthdayGiftData {
  try {
    window.localStorage.removeItem(STORAGE_KEY);
    if (window.location.hash.startsWith("#gift=")) {
      window.history.replaceState(null, "", window.location.pathname + window.location.search);
    }
  } catch {
    // Ignore
  }
  return DEFAULT_GIFT_DATA;
}

export function createShareableGiftUrl(data: BirthdayGiftData): string {
  const encoded = encodeBase64Utf8(JSON.stringify(data));
  const base = `${window.location.origin}${window.location.pathname}`;
  return `${base}#gift=${encoded}`;
}
